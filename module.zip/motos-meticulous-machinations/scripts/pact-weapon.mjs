const cpr = "chris-premades";
const pactEnchantments = new Set(["pactOfTheBladeBondedEnchantment", "pactWeapon"]);

export function isPactWeapon(weapon) {
    if (weapon?.type !== "weapon") return false;
    if (weapon.flags?.[cpr]?.info?.identifier === "pactWeapon" ||
        weapon.flags?.[cpr]?.macros?.midi?.item?.includes("pactOfTheBladeAttack")) return true;
    for (const effect of weapon.allApplicableEffects?.() ?? weapon.effects ?? []) {
        if (!effect.active) continue;
        if (pactEnchantments.has(effect.flags?.[cpr]?.info?.identifier)) return true;
        // DDB Importer adds this name change to the actual enchantment on the weapon.
        if (effect.type === "enchantment" && effect.changes.some(change =>
            change.key === "name" && /\[Pact Weapon\]/i.test(change.value))) return true;
    }
    return false;
}
