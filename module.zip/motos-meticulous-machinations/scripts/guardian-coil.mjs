import {buttons, promptSession} from "./prompts.mjs";

const moduleId = "motos-meticulous-machinations";
const cpr = "chris-premades";
const coilId = "guardianCoil";
const summonId = "tentacleOfTheDeeps";
const handled = new WeakSet();
const claims = new Map();
let socket;

const coilFor = actor => chrisPremades.utils.itemUtils.getItemByIdentifier(actor, coilId);
const escape = text => foundry.utils.escapeHTML(text);

function tentaclesFor(source, scene) {
    const effect = chrisPremades.utils.effectUtils.getEffectByIdentifier(source.actor, summonId);
    if (!effect || effect.active === false || effect.updateDuration?.()?.remaining === 0) return [];
    const summons = effect.flags[cpr]?.summons;
    const ids = summons?.ids?.[effect.name] ?? [];
    const scenes = summons?.scenes?.[effect.name] ?? [];
    return ids.flatMap((id, index) => {
        if (scenes[index] && scenes[index] !== scene.id) return [];
        return scene.tokens.get(id)?.object ?? [];
    });
}

function eligibleTentacle(source, target, scene) {
    const {actorUtils, tokenUtils} = chrisPremades.utils;
    const recipient = target.actor;
    const self = source.actor.uuid === recipient.uuid;
    if (actorUtils.hasUsedReaction(source.actor) || MidiQOL.checkIncapacitated(source.actor, false, false)) return;
    if (!self && (source.document.disposition !== target.document.disposition ||
        source.document.disposition === CONST.TOKEN_DISPOSITIONS.NEUTRAL ||
        source.document.disposition === CONST.TOKEN_DISPOSITIONS.SECRET || !tokenUtils.canSee(source, target))) return;
    return tentaclesFor(source, scene).find(tentacle => {
        const distance = MidiQOL.getDistance(tentacle, target, {wallsBlock: false, includeCover: false});
        return tentacle !== target && distance >= 0 && distance <= 10;
    });
}

async function claimReaction(actorUuid) {
    const prior = claims.get(actorUuid) ?? Promise.resolve();
    const claim = prior.catch(() => {}).then(async () => {
        const actor = await fromUuid(actorUuid);
        if (!actor?.isOwner || !coilFor(actor) || MidiQOL.hasUsedReaction(actor) ||
            MidiQOL.checkIncapacitated(actor, false, false)) return false;
        await MidiQOL.setReactionUsed(actor);
        return true;
    });
    claims.set(actorUuid, claim);
    try {
        return await claim;
    } finally {
        if (claims.get(actorUuid) === claim) claims.delete(actorUuid);
    }
}

async function spendReaction(actor) {
    const gm = game.users.activeGM;
    try {
        if (gm && gm.id !== game.user.id) return await socket?.executeAsUser("claimMachinationsGuardianCoil", gm.id, actor.uuid);
        return await claimReaction(actor.uuid);
    } catch (error) {
        console.warn("Machinations could not spend the Guardian Coil Reaction", error);
        return false;
    }
}

function panel(heading, detail) {
    return `<section style="padding:16px;border:1px solid #75c4cb;border-radius:12px;background:radial-gradient(ellipse at top right,#164153,#122736 70%);color:#e3f6f7;line-height:1.5;overflow-wrap:anywhere">
        <h2 style="margin:0 0 8px;color:#a6e8e6;border:0">${heading}</h2><p style="margin:0">${detail}</p>
    </section>`;
}

function reduceDamage(damage, rolled) {
    const reduction = Math.min(rolled, damage.healingAdjustedTotalDamage);
    const remaining = damage.healingAdjustedTotalDamage - reduction;
    const adjustment = {type: "none", value: -reduction, damage: -reduction, active: {multiplier: 1}};
    damage.damageDetail.push(adjustment);
    damage.rawDamageDetail.push({...adjustment});
    const temporaryGranted = damage.damageDetail.filter(entry => entry.type === "temphp")
        .reduce((total, entry) => total + entry.value, 0);
    const absorbed = Math.min(damage.oldTempHP, remaining);
    damage.newTempHP = Math.floor(Math.max(damage.oldTempHP - absorbed, temporaryGranted));
    damage.tempDamage = damage.oldTempHP - damage.newTempHP;
    damage.hpDamage = Math.min(damage.oldHP, remaining - absorbed);
    damage.newHP = damage.oldHP - damage.hpDamage;
    damage.totalDamage -= reduction;
    damage.healingAdjustedTotalDamage = remaining;
    return reduction;
}

async function animate(item, tentacle, target) {
    const {itemUtils} = chrisPremades.utils;
    if (!itemUtils.getConfig(item, "playAnimation") || !globalThis.Sequence) return;
    const file = String(itemUtils.getConfig(item, "coilAnimation") ?? "").trim();
    try {
        if (file && (!file.startsWith("jb2a.") || globalThis.Sequencer?.Database?.entryExists(file))) {
            await new Sequence().effect().file(file).atLocation(tentacle).stretchTo(target).play();
        }
    } catch (error) {
        console.warn("Machinations could not play the Guardian Coil animation", error);
    }
}

async function offer({trigger, workflow, ditem: damage}) {
    const target = trigger.targetToken ?? trigger.token;
    const scene = target?.document?.parent;
    if (!target?.actor || !scene || !damage?.damageDetail || !damage.rawDamageDetail ||
        damage.wasHit === false || damage.isHit === false || damage.targetUuid !== target.document.uuid ||
        target.actor.statuses.has("dead") || handled.has(damage)) return;
    const phase = workflow.currentAction;
    const valid = () => !workflow.aborted && workflow.currentAction === phase && damage.healingAdjustedTotalDamage > 0;
    if (!valid()) return;
    handled.add(damage);
    const candidates = new Map();
    for (const token of scene.tokens) {
        const source = token.object;
        if (!source?.actor || candidates.has(source.actor.uuid)) continue;
        const item = coilFor(source.actor);
        if (item && eligibleTentacle(source, target, scene)) candidates.set(source.actor.uuid, {source, item});
    }
    if (!candidates.size) return;

    const selfId = target.actor.uuid;
    let choice = selfId;
    if (candidates.size > 1 || !candidates.has(selfId)) {
        const options = [...candidates].map(([id, {source}]) =>
            [id === selfId ? "Use My Guardian Coil" : `Ask ${escape(source.name)} for Guardian Coil`, id]);
        options.push(["Take the Damage", "decline"]);
        choice = await buttons(promptSession(target.actor, valid), "Guardian Coil",
            panel("Call to the Deep", "You are about to take damage. Choose whose Guardian Coil you want to request. That warlock decides whether to spend their Reaction."),
            options);
    }
    const candidate = candidates.get(choice);
    if (!candidate) return;
    const {source, item} = candidate;
    const ready = () => valid() && coilFor(source.actor)?.id === item.id && !!eligibleTentacle(source, target, scene);
    if (!ready()) return;
    const level = source.actor.classes?.warlock?.system?.levels ?? 0;
    const formula = level >= 10 ? "2d8" : "1d8";
    const subject = choice === selfId ? "You are about to take damage." :
        `<strong>${escape(target.name)}</strong> requests your Guardian Coil.`;
    const approval = await buttons(promptSession(source.actor, ready), "Guardian Coil",
        panel("Interpose the Tentacle", `${subject} Spend your Reaction to reduce the incoming damage by <strong>${formula}</strong>?`),
        [["Use Guardian Coil", "use"], ["Decline", "decline"]]);
    if (approval !== "use" || !ready()) return;
    const roll = await new Roll(formula).evaluate();
    const tentacle = eligibleTentacle(source, target, scene);
    if (!tentacle || !valid() || !await spendReaction(source.actor)) return;
    const reduction = reduceDamage(damage, roll.total);
    void animate(item, tentacle, target);
    await roll.toMessage({
        speaker: ChatMessage.implementation.getSpeaker({token: source.document}),
        flavor: `Guardian Coil reduces damage to ${escape(target.name)} by ${reduction}.`
    });
}

Hooks.once("socketlib.ready", () => {
    socket = globalThis.socketlib?.registerModule(moduleId);
    socket?.register("claimMachinationsGuardianCoil", claimReaction);
});
Hooks.once("ready", () => {
    const module = game.modules.get(moduleId);
    module.api = {...module.api, guardianCoil: {offer}};
});
