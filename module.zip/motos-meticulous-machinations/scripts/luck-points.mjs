const moduleId = "motos-meticulous-machinations";
const cpr = "chris-premades";
const pooledPath = `flags.${moduleId}.usesLuckyPool`;
const luckyId = "luckyOrigin";
const protectedId = "protectedOrigin";
const baseFormula = "@prof";
const stackedFormula = "2 * @prof";
const queues = new Map();
let socket;

const identifier = item => item?.flags?.[cpr]?.info?.identifier;
const isLuckFeat = id => id === luckyId || id === protectedId;
const isSecondary = item => item?.flags?.[moduleId]?.usesLuckyPool === true;
const rawUses = item => item?._source?.system?.uses ?? item?.system?.uses;
const spent = item => rawUses(item)?.spent ?? 0;

export function getLuckFeat(actor, id) {
    return actor?.items?.find(item => identifier(item) === id);
}

function getPool(actor) {
    const lucky = getLuckFeat(actor, luckyId);
    const protectedFeat = getLuckFeat(actor, protectedId);
    return {lucky, protectedFeat, pool: lucky ?? protectedFeat};
}

export function luckPoints(item) {
    const {lucky, protectedFeat, pool} = getPool(item.actor);
    if (!pool || (item.id !== lucky?.id && item.id !== protectedFeat?.id)) return 0;
    const multiplier = lucky && protectedFeat && lucky.flags[cpr].config?.luckPool !== "shared" ? 2 : 1;
    const remaining = multiplier * (item.actor.system.attributes.prof ?? 0) - spent(pool);
    return Math.max(0, remaining - (lucky && !isSecondary(protectedFeat) ? spent(protectedFeat) : 0));
}

async function reconcile(actor, removed) {
    const {lucky, protectedFeat, pool} = getPool(actor);
    if (!pool) return;
    const combined = !!(lucky && protectedFeat);
    const max = combined && lucky.flags[cpr].config?.luckPool !== "shared" ? stackedFormula : baseFormula;
    let totalSpent = spent(pool);
    if (combined && !isSecondary(protectedFeat)) totalSpent += spent(protectedFeat);
    if (!lucky && isSecondary(protectedFeat) && removed?.identifier === luckyId) totalSpent += removed.spent;

    const updates = [];
    if (rawUses(pool)?.max !== max || spent(pool) !== totalSpent || isSecondary(pool)) {
        const update = {_id: pool.id, "system.uses.max": max, "system.uses.spent": totalSpent};
        if (isSecondary(pool)) update[`flags.${moduleId}.-=usesLuckyPool`] = null;
        updates.push(update);
    }
    if (combined && (!isSecondary(protectedFeat) || rawUses(protectedFeat)?.max || spent(protectedFeat))) {
        updates.push({_id: protectedFeat.id, "system.uses.max": "", "system.uses.spent": 0, [pooledPath]: true});
    }
    if (updates.length) await actor.updateEmbeddedDocuments("Item", updates, {mmmLuckPool: true});
}

function enqueue(actorUuid, run) {
    const prior = queues.get(actorUuid) ?? Promise.resolve();
    const work = prior.catch(() => {}).then(async () => {
        const actor = await fromUuid(actorUuid);
        if (actor?.isOwner) return run(actor);
    });
    queues.set(actorUuid, work);
    return work.finally(() => {
        if (queues.get(actorUuid) === work) queues.delete(actorUuid);
    });
}

function syncLuckPool(actorUuid, removed) {
    return enqueue(actorUuid, actor => reconcile(actor, removed));
}

function consumeLuckPoint(actorUuid, itemId) {
    return enqueue(actorUuid, async actor => {
        await reconcile(actor);
        const item = actor.items.get(itemId);
        if (!isLuckFeat(identifier(item)) || luckPoints(item) < 1) return false;
        const {pool} = getPool(actor);
        await pool.update({"system.uses.spent": spent(pool) + 1}, {mmmLuckPool: true});
        return true;
    });
}

function onAuthority(actor, handler, local, ...args) {
    const gm = game.users.activeGM;
    if (gm && gm.id !== game.user.id) return socket?.executeAsUser(handler, gm.id, actor.uuid, ...args);
    if (actor.isOwner) return local(actor.uuid, ...args);
}

export async function spendLuckPoint(item) {
    if (!item?.actor) return false;
    try {
        return await onAuthority(item.actor, "consumeMachinationsLuckPoint", consumeLuckPoint, item.id) === true;
    } catch (error) {
        console.error("Machinations could not spend the Luck Point", error);
        return false;
    }
}

function syncOwnedItem(item, options, userId, removed) {
    if (userId !== game.user.id || options.mmmLuckPool || !item.actor || !isLuckFeat(removed?.identifier ?? identifier(item))) return;
    return Promise.resolve(onAuthority(item.actor, "syncMachinationsLuckPool", syncLuckPool, removed))
        .catch(error => console.error("Machinations could not sync the Luck Point pool", error));
}

Hooks.once("socketlib.ready", () => {
    socket = socketlib.registerModule(moduleId);
    socket.register("syncMachinationsLuckPool", syncLuckPool);
    socket.register("consumeMachinationsLuckPoint", consumeLuckPoint);
});

Hooks.on("createItem", (item, options, userId) => syncOwnedItem(item, options, userId));
Hooks.on("deleteItem", (item, options, userId) => {
    return syncOwnedItem(item, options, userId, {identifier: identifier(item), spent: spent(item)});
});
Hooks.on("updateItem", (item, changes, options, userId) => {
    if (!changes.system?.uses && !changes.flags?.[cpr]) return;
    return syncOwnedItem(item, options, userId, options.mmmRemovedLuckFeat);
});

Hooks.on("preUpdateItem", (item, changes, options) => {
    const incoming = changes.flags?.[cpr];
    if (options.diff !== false || !item.actor || !changes.system?.uses || !incoming?.info) return;
    if (!isLuckFeat(incoming.info.identifier)) {
        if (isLuckFeat(identifier(item))) options.mmmRemovedLuckFeat = {identifier: identifier(item), spent: spent(item)};
        return;
    }
    // CPR replaces non-spell uses when applying a Medkit automation.
    changes.system.uses.spent = spent(item);
    if (isSecondary(item)) foundry.utils.setProperty(changes, pooledPath, true);
    if (identifier(item) === incoming.info.identifier && item.flags[cpr].config) {
        incoming.config = {...incoming.config, ...item.flags[cpr].config};
    }
});
