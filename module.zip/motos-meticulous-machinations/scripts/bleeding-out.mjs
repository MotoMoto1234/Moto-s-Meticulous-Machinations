import {offerNobleSacrifice} from "./noble-sacrifice.mjs";

let moduleId = "motos-meticulous-machinations";
let statusId = "bleeding-out";
let setting = "manageBleedingOut";
let imageSetting = "bleedingOutImage";
let tokenArtSetting = "bleedingOutTokenArt";
let defaultImage = "icons/svg/blood.svg";
let autoDamageModes = new Set(["yes", "yesCard", "yesCardMisses", "yesCardNPC"]);
let attackTypes = new Set(["mwak", "msak", "rwak", "rsak"]);
let jobs = new Map();
let attemptedTurns = new Map();
let rollsInFlight = new Map();
let damageLocks = new Map();
let lastMode;
let socket;
let activeGM = () => game.users.activeGM?.isSelf;
let hp = actor => actor?.system.attributes?.hp?.value;
let death = actor => actor?.system.attributes?.death;
let effectStatus = (effect, id) => effect.statuses.has(id) ||
    effect.name === ({[statusId]: "Bleeding Out", stable: "Stable", dead: "Dead"})[id];
let statusEffect = (actor, id) => actor?.effects.find(effect => !effect.disabled && effectStatus(effect, id));
let hasStatus = (actor, id) => actor?.statuses.has(id) || Boolean(statusEffect(actor, id));
let eligible = actor => ["character", "npc"].includes(actor?.type) && Boolean(death(actor)) && Number.isFinite(hp(actor));
let isSteelDefender = actor => actor.flags.world?.persistentSteelDefender?.role === "defender";
let isBoundSteed = actor => {
    let bond = actor.flags.world?.faithfulSteedBond;
    return bond?.role === "steed" && Boolean(bond.paladinUuid);
};
let midiSettings = () => game.settings.get("midi-qol", "ConfigSettings");
let cpr = () => globalThis.chrisPremades?.utils;
let isManaged = () => lastMode === "managed" && midiSettings()?.addDead === "none";
let isBleeding = actor => eligible(actor) && hp(actor) === 0 && hasStatus(actor, statusId) &&
    !hasStatus(actor, "stable") && !hasStatus(actor, "dead");
let safe = value => foundry.utils.escapeHTML(String(value));
let bleedingOutImage = () => game.settings.get(moduleId, imageSetting)?.trim() || defaultImage;

let status = {
    id: statusId, _id: "machBleedingOut1", name: "Bleeding Out",
    changes: [
        {key: "flags.midi-qol.fail.ability.save.dex", mode: 0, value: "1", priority: 20},
        {key: "flags.midi-qol.fail.ability.save.str", mode: 0, value: "1", priority: 20},
        {key: "flags.midi-qol.grants.advantage.attack.all", mode: 0, value: "1", priority: 20},
        {key: "flags.midi-qol.grants.critical.range", mode: 5, value: "7", priority: 20}
    ],
    flags: {dae: {showIcon: true, stackable: "noneName"}, [moduleId]: {managedBleeding: true}}
};

function isLegacy(effect) {
    if (!effect) return false;
    let flags = effect.flags["chris-premades"];
    return Boolean(flags?.embeddedMacros?.some(macro =>
        (macro.type === "combat" && macro.pass === "turnStart") ||
        (macro.type === "effect" && macro.pass === "created"))) ||
        effect.changes.some(change => (change.key === "flags.midi-qol.onUseMacroName" &&
            change.value.includes("preTargetDamageApplication")) ||
            (change.key.startsWith("macro.") && ![undefined, "", "none"].includes(effect.flags.dae?.macroRepeat)));
}

function legacyDefinition() {
    if (!game.settings.get("chris-premades", "effectInterface")) return;
    let registry = game.items.find(item => item.flags["chris-premades"]?.effectInterface);
    return registry?.effects.find(effect => {
        let config = effect.flags["chris-premades"]?.effectInterface;
        return config?.customStatus === statusId || config?.status === statusId;
    });
}

function midiUsesBleedingOut(actor) {
    let config = midiSettings();
    if (config?.addDead === "none") return false;
    let playerRules = actor.type === "character" || actor.hasPlayerOwner || actor.system.traits?.important;
    return (playerRules ? config?.midiUnconsciousCondition : config?.midiDeadCondition) === statusId;
}

function legacyOffersNoble(actor, reason) {
    let current = statusEffect(actor, statusId);
    let definition = midiUsesBleedingOut(actor) ? legacyDefinition() : null;
    let callsOffer = code => /await\s+nobleOffer\s*\(/.test(code ?? "");
    if (reason === "dropped") return Boolean(definition?.flags["chris-premades"]?.embeddedMacros?.some(macro =>
        macro.type === "effect" && macro.pass === "created" && callsOffer(macro.macro)));
    let legacy = current ?? definition;
    return Boolean(legacy?.flags["chris-premades"]?.embeddedMacros?.some(macro =>
        macro.type === "combat" && macro.pass === "turnStart" && callsOffer(macro.macro))) ||
        Boolean(legacy?.changes.some(change => {
            if (change.key !== "flags.midi-qol.onUseMacroName") return false;
            let [name, pass] = change.value.split(",").map(part => part.trim());
            return pass === "preTargetDamageApplication" && callsOffer(game.macros?.getName(name)?.command);
        }));
}

function registerStatuses() {
    if (!legacyDefinition() && !CONFIG.statusEffects.some(entry => entry.id === statusId)) {
        let definition = foundry.utils.deepClone(status);
        definition.img = bleedingOutImage();
        if (game.modules.get("ATL")?.active && game.settings.get(moduleId, tokenArtSetting)) {
            definition.changes.push(
                {key: "ATL.texture.src", mode: 5, value: definition.img, priority: 20},
                {key: "ATL.texture.scaleX", mode: 5, value: "1.6", priority: 20},
                {key: "ATL.texture.scaleY", mode: 5, value: "1.6", priority: 20}
            );
        }
        CONFIG.statusEffects.push(definition);
    }
    if (!CONFIG.statusEffects.some(entry => entry.id === "stable")) {
        CONFIG.statusEffects.push({id: "stable", _id: "machStableStatus", name: "Stable", img: "icons/svg/sleep.svg"});
    }
}

function initialize() {
    lastMode = "compatibility";
    let config = midiSettings();
    if (config?.addDead !== "none" && [config?.midiDeadCondition, config?.midiUnconsciousCondition].includes(statusId)) registerStatuses();
    if (!game.settings.get(moduleId, setting)) return;
    let conflict = legacyDefinition() ? "Remove the custom Bleeding Out status from CPR's Effects sidebar."
        : midiSettings().addDead !== "none" ? "Set Midi-QOL's automatic status on reaching 0 HP to None."
        : !socket ? "SocketLib could not register Machinations. Restart the Foundry server after updating the module."
        : !cpr() ? "CPR's API is unavailable. Check that CPR is enabled and check the startup console for errors."
        : "";
    if (conflict) {
        if (activeGM()) ui.notifications.warn("Machinations Bleeding Out is in compatibility mode. " + conflict, {permanent: true});
        return;
    }
    registerStatuses();
    lastMode = "managed";
    if (activeGM() && !autoDamageModes.has(midiSettings().autoApplyDamage)) {
        ui.notifications.warn("Machinations counts damage-caused death save failures with Midi-QOL automatic damage application. Resolve manual damage cards' failures at the table.");
    }
}

async function clearStatuses(actor, ids) {
    let effects = actor.effects.filter(effect => ids.some(id => effectStatus(effect, id)));
    if (effects.length) await cpr().genericUtils.deleteEmbeddedDocuments(actor, "ActiveEffect", effects.map(effect => effect.id));
}

async function addStatus(actor, id) {
    if (hasStatus(actor, id)) return;
    let effect = await ActiveEffect.implementation.fromStatusEffect(id);
    let data = effect.toObject();
    if (id === statusId) data.img = bleedingOutImage();
    await cpr().genericUtils.createEmbeddedDocuments(actor, "ActiveEffect", [data], {keepId: true});
}

async function makeDead(actor) {
    if (hp(actor) !== 0) return;
    await clearStatuses(actor, [statusId, "stable"]);
    if (hp(actor) === 0) await addStatus(actor, "dead");
}

function enqueue(queues, key, run) {
    let next = (queues.get(key) ?? Promise.resolve()).catch(() => {}).then(run).finally(() => {
        if (queues.get(key) === next) queues.delete(key);
    });
    queues.set(key, next);
    return next;
}

function fail(label, error) {
    console.error("Machinations Bleeding Out: " + label, error);
    ui.notifications.warn("Machinations could not finish " + label + ". Check the console before resolving it manually.");
}

function beforeHPUpdate(actor, change, options) {
    if (!eligible(actor)) return;
    if (foundry.utils.getProperty(change, "system.attributes.hp.value") === undefined &&
        foundry.utils.getProperty(change, "system.attributes.death.failure") === undefined) return;
    let previous = options[moduleId] ??= {};
    previous[actor.uuid] = {hp: hp(actor), failures: death(actor).failure};
}

async function hitZero(actor, token) {
    if (!isManaged() || hp(actor) !== 0 || hasStatus(actor, "dead") || hasStatus(actor, "stable") || statusEffect(actor, statusId)) return;
    if (actor.flags["chris-premades"]?.endureDeath) return;
    if (isSteelDefender(actor)) {
        if (actor.flags.world.persistentSteelDefender.built) {
            await actor.update({"flags.world.persistentSteelDefender.destroyedAt":
                actor.flags.world.persistentSteelDefender.destroyedAt ?? game.time.worldTime});
        }
        await makeDead(actor);
        return;
    }
    await addStatus(actor, statusId);
    await addStatus(actor, "prone");
    if (!isBleeding(actor)) return;
    if (await offerNobleSacrifice(token, "dropped") || !isBleeding(actor)) return;
    let type = actor.system.details?.type;
    let creature = typeof type === "string" ? type : type?.custom || type?.value;
    let immediate = await cpr().dialogUtils.confirm("Should this creature die?",
        `<p><strong>${safe(token?.name ?? actor.name)}</strong> reached 0 HP (${safe(creature ?? "unknown creature type")}). Choose Yes to mark it Dead or No to leave it Bleeding Out.</p>`,
        {userId: game.user.id});
    if (immediate && isBleeding(actor)) await makeDead(actor);
}

function onHPUpdate(actor, change, options) {
    if (!lastMode || !activeGM() || !eligible(actor) || isBoundSteed(actor)) return;
    let before = options[moduleId]?.[actor.uuid];
    let dropped = before?.hp > 0 && hp(actor) === 0;
    let thirdFailure = before?.hp === 0 && before.failures < 3 && death(actor).failure >= 3 &&
        foundry.utils.getProperty(change, "system.attributes.death.failure") !== undefined;
    if (!isManaged()) {
        if (hp(actor) !== 0 || (!dropped && !thirdFailure) || !cpr() || isSteelDefender(actor) ||
            actor.flags["chris-premades"]?.endureDeath) return;
        let reason = dropped ? "dropped" : "failure";
        if (legacyOffersNoble(actor, reason)) return;
        let token = actor.token?.object ?? cpr().actorUtils.getFirstToken(actor);
        return enqueue(jobs, actor.uuid, () => {
            if (!thirdFailure || death(actor).failure >= 3) return offerNobleSacrifice(token, reason, {verifiedTransition: true});
        })
            .catch(error => fail("the Noble Sacrifice reaction", error));
    }
    if (foundry.utils.getProperty(change, "system.attributes.hp.value") === undefined) return;
    if (dropped) {
        let token = actor.token?.object ?? cpr().actorUtils.getFirstToken(actor);
        return enqueue(jobs, actor.uuid, () => hitZero(actor, token)).catch(error => fail("the 0 HP transition", error));
    } else if (hp(actor) > 0 && [statusId, "stable"].some(id => hasStatus(actor, id))) {
        return enqueue(jobs, actor.uuid, async () => {
            if (hp(actor) <= 0) return;
            let bleed = statusEffect(actor, statusId);
            if (!bleed || !isLegacy(bleed)) await clearStatuses(actor, [statusId, "stable"]);
        }).catch(error => fail("the recovery from 0 HP", error));
    }
}

function currentTurn(combat, request) {
    return combat?.isActive && combat.started && combat.round === request.round &&
        combat.turn === request.turn && combat.combatant?.id === request.combatantId;
}

function canSave(actor) {
    return isManaged() && isBleeding(actor) && !isBoundSteed(actor) && !isLegacy(statusEffect(actor, statusId)) &&
        death(actor).success < 3 && death(actor).failure < 3;
}

async function rollForCurrentCombatant(request) {
    let combat = game.combats.get(request.combatId);
    if (!currentTurn(combat, request)) return null;
    let actor = combat.combatant.actor;
    if (actor.uuid !== request.actorUuid || !actor.isOwner || !canSave(actor)) return null;
    if (rollsInFlight.has(actor.uuid)) return null;
    rollsInFlight.set(actor.uuid, request);
    try {
        let response = await actor.rollDeathSave({}, {configure: true}, {create: true});
        let roll = response?.[0];
        if (!roll) return null;
        let success = roll.total >= (roll.options.target ?? 10);
        return {success, revived: success && roll.isCritical, failures: !success && roll.isFumble ? 2 : 1};
    } finally {
        rollsInFlight.delete(actor.uuid);
    }
}

function saveOwner(actor) {
    let selected = cpr().socketUtils.firstOwner(actor, true);
    return game.users.get(selected)?.active ? selected : game.user.id;
}

async function remindAboutAnkh(actor, userId) {
    let ankh = actor.items.find(item => item.system.equipped && item.system.quantity > 0 &&
        (item.flags["chris-premades"]?.info?.identifier === "lifeTetherAnkh" ||
            item.system.identifier === "life-tether-ankh" || item.name === "Life Tether Ankh") &&
        (!item.system.uses?.max || item.system.uses.value > 0));
    if (!ankh) return true;
    let description = await foundry.applications.ux.TextEditor.implementation.enrichHTML(ankh.system.description.value,
        {relativeTo: ankh, secrets: game.users.get(userId)?.isGM === true});
    let answer = await cpr().dialogUtils.buttonDialog("Life Tether Ankh",
        `<div style="border:1px solid #b89450;border-radius:12px;padding:16px;background:#292015;color:#f2e9d7"><h3>${safe(ankh.name)}</h3>${description}<p>Resolve use of the equipped Ankh manually with your GM before continuing.</p></div>`,
        [["Continue to Death Save", "continue"], ["Pause for Manual Resolution", "pause"]], {userId});
    return answer === "continue";
}

async function turnSave(combat, actor, request) {
    if (!currentTurn(combat, request) || !canSave(actor)) return;
    let userId = saveOwner(actor);
    if (!await remindAboutAnkh(actor, userId)) return;
    while (currentTurn(combat, request) && canSave(actor)) {
        let prior = {...death(actor)};
        let rolled = userId === game.user.id ? await rollForCurrentCombatant(request)
            : await socket.executeAsUser("rollBleedingOutDeathSave", userId, request);
        if (!rolled) {
            if (!currentTurn(combat, request) || !canSave(actor)) return;
            let retry = await cpr().dialogUtils.buttonDialog("Death Save Cancelled",
                "<p>Retry the save or pause to resolve this turn with the GM.</p>",
                [["Retry Death Save", "retry"], ["Pause for Manual Resolution", "pause"]], {userId});
            if (retry !== "retry") return;
            continue;
        }
        if (!currentTurn(combat, request)) return;
        if (rolled.revived || hp(actor) > 0) {
            await clearStatuses(actor, [statusId, "stable"]);
            return;
        }
        if (!isBleeding(actor)) return;
        if (rolled.success && prior.success === 2) {
            await clearStatuses(actor, [statusId]);
            if (hp(actor) === 0) await addStatus(actor, "stable");
        } else if (!rolled.success && prior.failure + rolled.failures >= 3) {
            let token = combat.combatant.token?.object;
            if (await offerNobleSacrifice(token, "roll") || hp(actor) !== 0) return;
            await makeDead(actor);
        }
        if (currentTurn(combat, request)) await combat.nextTurn();
        return;
    }
}

function onTurnChange(combat, previous, current) {
    if (!activeGM() || !isManaged() || !combat.isActive || !combat.started) return;
    if (previous && (current.round < previous.round || (current.round === previous.round && current.turn < previous.turn))) return;
    let combatant = combat.combatant;
    let actor = combatant?.actor;
    if (!eligible(actor) || hp(actor) !== 0) return;
    let key = `${combat.round}:${combat.turn}:${combatant.id}`;
    if (attemptedTurns.get(combat.id) === key) return;
    attemptedTurns.set(combat.id, key);
    let request = {combatId: combat.id, combatantId: combatant.id, actorUuid: actor.uuid,
        round: combat.round, turn: combat.turn};
    return enqueue(jobs, actor.uuid, () => turnSave(combat, actor, request)).catch(error => fail("the turn-start death save", error));
}

function damageAppliedTo(actor) {
    let mode = midiSettings().autoApplyDamage;
    return autoDamageModes.has(mode) && (mode !== "yesCardNPC" || actor.type !== "character");
}

async function onDamageWhileDown(token, {workflow, damageItem}) {
    let actor = token?.actor;
    if (!isManaged() || !eligible(actor) || isBoundSteed(actor) || hp(actor) !== 0 || hasStatus(actor, "dead") ||
        !damageAppliedTo(actor) || damageItem?.wasHit === false || !(damageItem?.healingAdjustedTotalDamage > 0)) return;
    let bleed = statusEffect(actor, statusId);
    let stable = statusEffect(actor, "stable");
    if ((!bleed && !stable) || (bleed && isLegacy(bleed))) return;
    let attack = attackTypes.has(workflow.activity?.actionType);
    await enqueue(damageLocks, actor.uuid, async () => {
        if (hp(actor) !== 0 || hasStatus(actor, "dead")) return;
        let stableNow = Boolean(statusEffect(actor, "stable"));
        let increment = attack && (workflow.isCritical || !stableNow) ? 2 : 1;
        let failures = Math.min(3, death(actor).failure + increment);
        await cpr().genericUtils.update(actor, {"system.attributes.death.failure": failures}, {}, true);
        if (hp(actor) !== 0) return;
        if (failures >= 3) {
            if (await offerNobleSacrifice(token, "damage")) {
                let temp = Number(actor.system.attributes.hp.temp ?? 0);
                let lost = Math.min(temp, Math.max(0, Number(damageItem.tempDamage) || 0));
                if (lost) await cpr().genericUtils.update(actor, {"system.attributes.hp.temp": temp - lost}, {}, true);
                cpr().workflowUtils.negateDamageItemDamage(damageItem);
                damageItem.healingAdjustedTotalDamage = 0;
                damageItem.oldHP = damageItem.newHP = hp(actor);
                damageItem.oldTempHP = damageItem.newTempHP = actor.system.attributes.hp.temp ?? 0;
            } else {
                await makeDead(actor);
            }
        } else if (stableNow) {
            await clearStatuses(actor, ["stable"]);
            if (hp(actor) === 0) await addStatus(actor, statusId);
        }
    });
}

Hooks.once("init", () => {
    game.settings.register(moduleId, setting, {
        name: "Manage Bleeding Out",
        hint: "Use Machinations for the 0 HP condition, death saves and damage failures. For an existing installation, switch off Midi-QOL's automatic 0 HP status and remove the old CPR custom status first.",
        scope: "world", config: true, type: Boolean, default: false, requiresReload: true
    });
    game.settings.register(moduleId, imageSetting, {
        name: "Bleeding Out Image",
        hint: "Choose the status icon and the image used by the optional Bleeding Out token art setting. Leave blank to use Foundry's blood icon.",
        scope: "world", config: true, type: String, filePicker: "image", default: defaultImage, requiresReload: true
    });
    game.settings.register(moduleId, tokenArtSetting, {
        name: "Use Bleeding Out Image as Token Art",
        hint: "With Active Token Effects enabled, temporarily use the Bleeding Out Image as the token's texture at 1.6 scale while the effect is active.",
        scope: "world", config: true, type: Boolean, default: false, requiresReload: true
    });
});
Hooks.once("socketlib.ready", () => {
    socket = globalThis.socketlib?.registerModule(moduleId);
    socket?.register("rollBleedingOutDeathSave", rollForCurrentCombatant);
});
Hooks.once("ready", initialize);
Hooks.on("preUpdateActor", beforeHPUpdate);
Hooks.on("updateActor", onHPUpdate);
Hooks.on("combatTurnChange", onTurnChange);
Hooks.on("deleteCombat", combat => attemptedTurns.delete(combat.id));
Hooks.on("midi-qol.preTargetDamageApplication", async (token, payload) => {
    try {
        await onDamageWhileDown(token, payload);
    } catch (error) {
        fail("death save failures from damage", error);
    }
});
