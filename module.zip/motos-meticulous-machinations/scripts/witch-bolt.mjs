const witchBoltScope = "chris-premades";
const witchBoltCastId = "attackWitchBoltI";
const witchBoltDamageId = "addOngoinDamage1";

function witchBoltState(effect) {
    return effect.flags[witchBoltScope]?.witchBoltTether;
}

function witchBoltControllers(actor) {
    return Array.from(actor?.effects ?? []).filter(effect => {
        return !effect.disabled && !effect.isSuppressed && witchBoltState(effect)?.role === "caster";
    });
}

function witchBoltController(item, sourceUuid) {
    return witchBoltControllers(item.actor).find(effect => {
        const state = witchBoltState(effect);
        return state.itemUuid === item.uuid && state.sourceUuid === sourceUuid;
    });
}

function witchBoltCombat(source) {
    const combat = game.combat;
    if (!combat?.started || !combat.turns.some(turn => turn.token?.uuid === source.document.uuid)) return;
    const combatant = combat.combatant;
    if (!combatant) return;
    return {key: [combat.id, combat.round, combatant.id].join(":"), ownTurn: combatant.token?.uuid === source.document.uuid};
}

function witchBoltTurnError(state, combat) {
    if (!combat) return;
    if (!combat.ownTurn || combat.key === state.castTurn) return "Ongoing Damage is available on your subsequent turns.";
    if (combat.key === state.damageTurn) return "You have already used Ongoing Damage this turn.";
}

async function witchBoltCheck(controller, removedUuid) {
    if (!controller || controller.disabled || controller.isSuppressed) return {};
    const state = witchBoltState(controller);
    const concentration = await fromUuid(state.concentrationUuid);
    if (!concentration || concentration.disabled || concentration.isSuppressed) return {};

    const [sourceDoc, targetDoc] = await Promise.all([fromUuid(state.sourceUuid), fromUuid(state.targetUuid)]);
    let reason;
    if (!sourceDoc || !targetDoc || sourceDoc.parent.id !== targetDoc.parent.id
        || [state.sourceUuid, state.targetUuid].includes(removedUuid)) {
        reason = "one of the tethered tokens left the scene";
    } else if (game.time.worldTime >= state.endsAt) {
        reason = "its duration expired";
    } else if (!sourceDoc.object || !targetDoc.object || canvas.scene?.id !== sourceDoc.parent.id) {
        return {};
    } else {
        const {genericUtils, tokenUtils} = chrisPremades.utils;
        const source = sourceDoc.object;
        const target = targetDoc.object;
        const distance = MidiQOL.getDistance(source, target, {includeCover: false});
        if (distance < 0) return {};
        if (distance > genericUtils.convertDistance(state.range)) {
            reason = "the target moved out of range";
        } else {
            const options = MidiQOL.configSettings().optionalRules ?? {};
            const totalCover = tokenUtils.checkCover(source, target, {}) >= 999;
            const wallBlocked = (!options.coverCalculation || options.coverCalculation === "none")
                && MidiQOL.getDistance(source, target, {wallsBlock: true}) < 0;
            if (!totalCover && !wallBlocked) return {source, target, state};
            reason = "the target has Total Cover";
        }
    }
    if (await fromUuid(concentration.uuid)) await genericUtils.remove(concentration);
    return {reason};
}

let witchBoltWallCheck;

function checkWitchBoltWalls(wall) {
    const scene = wall.parent;
    if (!globalThis.chrisPremades?.utils.socketUtils.isTheGM() || scene.id !== canvas.scene?.id) return;
    clearTimeout(witchBoltWallCheck);
    witchBoltWallCheck = setTimeout(async () => {
        if (canvas.scene?.id !== scene.id) return;
        const controllers = new Map();
        for (const token of scene.tokens) {
            for (const effect of witchBoltControllers(token.actor)) {
                if (witchBoltState(effect).sourceUuid === token.uuid) controllers.set(effect.uuid, effect);
            }
        }
        for (const effect of controllers.values()) await witchBoltCheck(effect);
    }, 75);
}

Hooks.on("createWall", checkWitchBoltWalls);
Hooks.on("updateWall", checkWitchBoltWalls);
Hooks.on("updateToken", async (token, changes) => {
    if (changes.elevation === undefined || token.parent.id !== canvas.scene?.id
        || !globalThis.chrisPremades?.utils.socketUtils.isTheGM() || !token.actor) return;
    for (const effect of token.actor.effects) {
        if (effect.disabled || effect.isSuppressed) continue;
        const state = witchBoltState(effect);
        if (!state || (state.sourceUuid !== token.uuid && state.targetUuid !== token.uuid)) continue;
        await witchBoltCheck(await fromUuid(state.controllerUuid));
    }
});
