import {buttons, promptSession} from "./prompts.mjs";
import {isPactWeapon} from "./pact-weapon.mjs";

const moduleId = "motos-meticulous-machinations";
const smiteId = "eldritchSmite2024";
const manualId = "manualSmite";
const optionKey = "machinationsEldritchSmite";
const spentKey = "eldritchSmiteUse";
const impactDefault = "jb2a.impact.009.purple";
const neutralFlash = "sepia(0) hue-rotate(0deg) saturate(1) brightness(1)";
const purpleFlash = [
    {filter: neutralFlash, offset: 0, composite: "add"},
    {filter: "sepia(0.65) hue-rotate(225deg) saturate(1.7) brightness(1.15)", offset: 0.24, composite: "add"},
    {filter: neutralFlash, offset: 1, composite: "add"}
];
const claims = new Map();
let socket;

const identifier = document => document?.flags?.["chris-premades"]?.info?.identifier;
const hitTokens = workflow => [...new Set([...(workflow.hitTargets ?? []), ...(workflow.hitTargetsEC ?? [])])];
const living = token => token.actor?.system.attributes.hp && !token.actor.statuses.has("dead");
const packConfig = (item, key) => chrisPremades.utils.itemUtils.getConfig(item, key);
const usedOnTurn = (actor, turn) => turn && actor.flags[moduleId]?.[spentKey]?.turn === turn;

function currentCombat(workflow) {
    const combat = workflow.token?.document?.combatant?.parent ?? game.combat;
    if (!combat?.started || !combat.current?.combatantId) return;
    if (combat.scene && workflow.token?.document?.parent?.id !== combat.scene.id) return;
    return combat;
}

function turnKey(combat) {
    if (!combat?.started || !combat.current?.combatantId) return "";
    return [combat.uuid, combat.round, combat.turn, combat.current.combatantId].join(":");
}

function availableSlot(actor, reserve) {
    const pact = actor.system.spells?.pact;
    return Number.isInteger(pact?.level) && pact.level > 0 && pact.value > reserve ? pact : undefined;
}

function reserveSlots(item) {
    return Math.max(0, Math.trunc(Number(packConfig(item, "reserveSlots")) || 0));
}

function wholeCR(actor) {
    const cr = actor.system.details?.cr;
    if (cr == null || cr === "") return -1;
    const [numerator, denominator = 1] = String(cr).split("/");
    const value = Number(numerator) / Number(denominator);
    return Number.isFinite(value) ? Math.ceil(value) : -1;
}

async function spendPactSlot({actorUuid, itemId, combatUuid, turn, workflowId, level, manual}) {
    const previous = claims.get(actorUuid) ?? Promise.resolve();
    const claim = previous.catch(() => {}).then(async () => {
        const actor = await fromUuid(actorUuid);
        const item = actor?.items?.get(itemId);
        if (!actor?.isOwner || identifier(item) !== smiteId) return false;
        const combat = combatUuid ? await fromUuid(combatUuid) : undefined;
        if (turn !== turnKey(combat) || usedOnTurn(actor, turn) ||
            actor.flags[moduleId]?.[spentKey]?.workflowId === workflowId) return false;
        const slot = availableSlot(actor, manual ? 0 : reserveSlots(item));
        if (!slot || slot.level !== level) return false;
        await actor.update({
            "system.spells.pact.value": slot.value - 1,
            [`flags.${moduleId}.${spentKey}`]: {turn, workflowId}
        });
        return true;
    });
    claims.set(actorUuid, claim);
    try {
        return await claim;
    } finally {
        if (claims.get(actorUuid) === claim) claims.delete(actorUuid);
    }
}

async function claimSlot(item, workflow, plan, level, manual = false) {
    const data = {actorUuid: item.actor.uuid, itemId: item.id, combatUuid: plan.combatUuid, turn: plan.turn,
        workflowId: workflow.id, level, manual};
    const gm = game.users.activeGM;
    try {
        if (gm && gm.id !== game.user.id) return await socket?.executeAsUser("spendMachinationsEldritchSmite", gm.id, data);
        return await spendPactSlot(data);
    } catch (error) {
        console.error("Machinations could not spend an Eldritch Smite slot", error);
        return false;
    }
}

function proneEligible(target) {
    const actor = target.actor;
    const {actorUtils} = chrisPremades.utils;
    const size = actorUtils.getSize(actor);
    return living(target) && Number.isInteger(size) && size <= 4 &&
        !actor.statuses.has("prone") && !actorUtils.checkTrait(actor, "ci", "prone");
}

async function criticalImmune(target, workflow, attackType) {
    const keys = ["grants.noCritical.all", "fail.critical.all"];
    if (attackType) keys.push(`grants.noCritical.${attackType}`, `fail.critical.${attackType}`);
    const flags = target.actor.flags["midi-qol"];
    const effects = target.actor.appliedEffects ?? [];
    const conditionData = MidiQOL.createConditionData({workflow, actor: workflow.actor, target});
    for (const key of keys) {
        const values = effects.flatMap(effect => effect.changes.filter(change =>
            change.key === "flags.midi-qol." + key).map(change => change.value));
        if (!values.length) values.push(foundry.utils.getProperty(flags, key));
        for (const value of values) {
            if (value && await MidiQOL.evalCondition(value, conditionData, {async: true, errorReturn: false})) return true;
        }
    }
    return false;
}

async function describeHit(item, workflow, target) {
    if (!living(target)) return;
    const hp = target.actor.system.attributes.hp;
    const max = hp.effectiveMax ?? hp.max;
    const hpPercent = 100 * hp.value / max;
    if ((packConfig(item, "healthWindowOnly") ?? true) && !(hpPercent >= 11 && hpPercent <= 75)) return;
    const minimumCR = Math.max(0, Math.ceil(Number(packConfig(item, "minCR")) || 0));
    if (minimumCR > 0 && wholeCR(target.actor) < minimumCR) return;
    const prone = proneEligible(target);
    const ignoreTraits = workflow.activity.midiProperties?.ignoreTraits;
    const forceImmune = !ignoreTraits?.has("idi") && !ignoreTraits?.has("idi.force") &&
        chrisPremades.utils.actorUtils.checkTrait(target.actor, "di", "force");
    if (forceImmune && !prone) return;
    const critical = workflow.isCritical && !await criticalImmune(target, workflow, workflow.activity.actionType);
    if (packConfig(item, "criticalOnly") && !critical) return;
    return {target, critical, prone, forceImmune};
}

function savePlan(workflow, plan) {
    workflow.workflowOptions = {...workflow.workflowOptions, [optionKey]: plan};
}

function panel(summary, detail) {
    return `<section style="padding:16px;border:1px solid #b69dd8;border-radius:12px;background:radial-gradient(ellipse at top right,#432958,#20192f 70%);color:#f5ebff;line-height:1.5;overflow-wrap:anywhere">
        <h2 style="margin:0 0 8px;color:#ddc0ff;border:0">Eldritch Smite</h2>
        <p style="margin:0 0 8px">${summary}</p><p style="margin:0">${detail}</p>
    </section>`;
}

async function offerSmite(item, workflow) {
    if (workflow.aborted || !workflow.attackRoll || workflow.isFumble || workflow.workflowOptions[optionKey] ||
        packConfig(item, "autoOffer") === false || MidiQOL.configSettings().autoCheckHit === "none" ||
        !["mwak", "rwak"].includes(workflow.activity?.actionType) ||
        !isPactWeapon(workflow.item)) return;
    const combat = currentCombat(workflow);
    const turn = turnKey(combat);
    const phase = workflow.currentAction;
    if (!turn && (packConfig(item, "combatOnly") ?? true)) return;
    const reserve = reserveSlots(item);
    const slot = availableSlot(item.actor, reserve);
    const valid = () => !workflow.aborted && workflow.currentAction === phase &&
        turnKey(currentCombat(workflow)) === turn && !usedOnTurn(item.actor, turn) && !!availableSlot(item.actor, reserve);
    if (!slot || !valid() || !hitTokens(workflow).length) return;

    const candidates = (await Promise.all(hitTokens(workflow).map(target => describeHit(item, workflow, target)))).filter(Boolean);
    if (!candidates.length || !valid()) return;
    savePlan(workflow, {phase: "offered"});
    const choices = new Map();
    const names = [];
    for (const {target, critical, prone, forceImmune} of candidates) {
        const uuid = target.document.uuid;
        const name = foundry.utils.escapeHTML(target.name);
        const label = critical ? "Critical smite" : "Smite";
        names.push(`<strong>${name}</strong> (${critical ? "critical hit" : "hit"})`);
        if (!forceImmune) choices.set(uuid, {label: `${label} ${target.name}`, uuid, prone: false, critical});
        if (prone) choices.set(uuid + ":prone", {label: forceImmune ? `Knock ${target.name} Prone (Force immune)` : `${label} ${target.name} and knock Prone`,
            uuid, prone: true, critical});
    }
    const selection = await buttons(promptSession(item.actor, valid), item.name,
        panel(`Spend one level ${slot.level} Pact Magic slot on a confirmed hit. ${slot.value} remaining.`,
            `${names.join(", ")}. The smite adds <strong>${slot.level + 1}d8 Force</strong> before critical modifiers.`),
        [...Array.from(choices, ([key, entry]) => [entry.label, key]), ["Continue Without Smite", "skip"]]);
    const choice = choices.get(selection);
    if (choice && valid() && hitTokens(workflow).some(token => token.document.uuid === choice.uuid)) {
        savePlan(workflow, {phase: "chosen", ...choice, turn, combatUuid: combat?.uuid});
    }
}

function smiteRoll(workflow, level, critical) {
    return new CONFIG.Dice.DamageRoll(`${level + 1}d8[force]`, workflow.activity.getRollData(),
        {isCritical: critical, type: "force", properties: ["mgc"], flavor: "Eldritch Smite"}).evaluate();
}

async function addSmiteDamage(item, workflow) {
    const plan = workflow.workflowOptions[optionKey];
    if (workflow.aborted || plan?.phase !== "chosen") return;
    const hits = hitTokens(workflow);
    const target = hits.find(token => token.document.uuid === plan.uuid);
    if (!target || !living(target) || turnKey(currentCombat(workflow)) !== plan.turn) return;
    const slot = availableSlot(item.actor, reserveSlots(item));
    if (!slot) return;
    savePlan(workflow, {...plan, phase: "resolving"});
    const critical = !!(workflow.isCritical && !await criticalImmune(target, workflow, workflow.activity.actionType));
    if (packConfig(item, "criticalOnly") && !critical) return;
    const roll = await smiteRoll(workflow, slot.level, critical);
    if (workflow.aborted || !await claimSlot(item, workflow, plan, slot.level)) return;
    const separate = hits.length > 1;
    if (!separate) await workflow.setBonusDamageRolls([...(workflow.bonusDamageRolls ?? []), roll]);
    savePlan(workflow, {...plan, phase: "spent", separate, critical, roll: separate ? roll.toJSON() : undefined});
}

async function playImpact(item, target) {
    if (!packConfig(item, "playAnimation") || !globalThis.Sequence) return;
    const file = String(packConfig(item, "impactAnimation") ?? impactDefault).trim();
    try {
        if (file && (!file.startsWith("jb2a.") || globalThis.Sequencer?.Database?.entryExists(file))) {
            await new Sequence().effect().file(file).atLocation(target).scaleToObject(1.35).play();
        }
    } catch (error) {
        console.warn("Machinations could not play the Eldritch Smite animation", error);
    }
}

function playScreenEffectOnClient(effect, sceneId) {
    const module = game.modules.get("eye-candy");
    if (!module?.active || globalThis.canvas?.scene?.id !== sceneId) return;
    const eyeCandy = module.api ?? globalThis.EyeCandy;
    if (effect === "shake" || effect === "both") eyeCandy?.earthquake(0.75, 340, 1, sceneId);
    if (effect === "flash" || effect === "both") eyeCandy?.customFilter(purpleFlash, 480, 1);
}

async function playScreenEffect(item, target) {
    const effect = packConfig(item, "screenEffect");
    const sceneId = target.document?.parent?.id;
    if (!["shake", "flash", "both"].includes(effect) || !sceneId || !socket || !game.modules.get("eye-candy")?.active) return;

    const viewers = game.users.filter(user => user.active && user.viewedScene === sceneId).map(user => user.id);
    if (!viewers.length) return;
    try {
        await socket.executeForUsers("playMachinationsEldritchSmiteScreenEffect", viewers, effect, sceneId);
    } catch (error) {
        console.warn("Machinations could not play the Eldritch Smite screen effect", error);
    }
}

function damageTarget(workflow, target, roll, critical) {
    return new MidiQOL.DamageOnlyWorkflow(workflow.actor, workflow.token, roll.total, "force", [target], roll,
        {flavor: "Eldritch Smite", itemCardUuid: "new", isCritical: critical});
}

async function finishSmite(item, workflow) {
    const plan = workflow.workflowOptions[optionKey];
    if (workflow.aborted || plan?.phase !== "spent") return;
    const target = hitTokens(workflow).find(token => token.document.uuid === plan.uuid);
    if (!target?.actor) return;
    savePlan(workflow, {...plan, phase: "finished"});
    if (plan.separate) damageTarget(workflow, target, Roll.fromData(plan.roll), plan.critical);
    void playScreenEffect(item, target);
    void playImpact(item, target);
    if (plan.prone && proneEligible(target)) await chrisPremades.utils.effectUtils.applyConditions(target.actor, ["prone"]);
}

async function manualSmite(item, workflow) {
    if (workflow.activity?.midiProperties?.identifier !== manualId || workflow.aborted) return;
    const targets = Array.from(workflow.targets ?? []);
    const target = targets.length === 1 ? targets[0] : undefined;
    if (!target?.actor || !living(target)) {
        ui.notifications.warn("Target one creature hit by the pact weapon.");
        return;
    }
    const combat = currentCombat(workflow);
    const turn = turnKey(combat);
    const slot = availableSlot(item.actor, 0);
    if (!slot || usedOnTurn(item.actor, turn)) {
        ui.notifications.warn(slot ? "Eldritch Smite was already used this turn." : "No Pact Magic spell slots remain.");
        return;
    }
    const valid = () => !workflow.aborted && turnKey(currentCombat(workflow)) === turn &&
        !usedOnTurn(item.actor, turn) && !!availableSlot(item.actor, 0) && living(target);
    const canProne = proneEligible(target);
    const weapon = item.actor.items.find(isPactWeapon);
    const attackType = weapon ? (weapon.system.attackType === "ranged" ? "rwak" : "mwak") : undefined;
    const canCrit = !await criticalImmune(target, workflow, attackType);
    const outcomes = [["Normal Smite", "normal"]];
    if (canProne) outcomes.push(["Normal Smite and Prone", "normal:prone"]);
    if (canCrit) outcomes.push(["Critical Smite", "critical"]);
    if (canProne && canCrit) outcomes.push(["Critical Smite and Prone", "critical:prone"]);
    outcomes.push(["Cancel", "skip"]);
    const name = foundry.utils.escapeHTML(target.name);
    const choice = await buttons(promptSession(item.actor, valid), "Manual Smite",
        panel(`Resolve a confirmed pact-weapon hit against <strong>${name}</strong>.`,
            `Choose the hit's effective result. Spend one level ${slot.level} Pact Magic slot for <strong>${slot.level + 1}d8 Force</strong> before critical modifiers.`),
        outcomes);
    if (!valid() || !choice || choice === "skip") return;
    const critical = choice.startsWith("critical");
    const roll = await smiteRoll(workflow, slot.level, critical);
    if (!valid() || !await claimSlot(item, workflow, {turn, combatUuid: combat?.uuid}, slot.level, true)) return;
    damageTarget(workflow, target, roll, critical);
    void playScreenEffect(item, target);
    void playImpact(item, target);
    if (choice.endsWith(":prone") && proneEligible(target)) await chrisPremades.utils.effectUtils.applyConditions(target.actor, ["prone"]);
}

Hooks.once("socketlib.ready", () => {
    socket = globalThis.socketlib?.registerModule(moduleId);
    socket?.register("spendMachinationsEldritchSmite", spendPactSlot);
    socket?.register("playMachinationsEldritchSmiteScreenEffect", playScreenEffectOnClient);
});

Hooks.once("ready", () => {
    const module = game.modules.get(moduleId);
    module.api = {...module.api, eldritchSmite: {offerSmite, addSmiteDamage, finishSmite, manualSmite}};
});
