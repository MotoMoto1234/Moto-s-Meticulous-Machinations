const moduleId = "motos-meticulous-machinations";
const casting = new Set();
let socket;

async function castOnGM({spellUuid, reactorUuid, slotKey, request}) {
    if (!game.user.isGM || !request?.id || typeof slotKey !== "string") return false;
    const [spell, reactor, source] = await Promise.all([
        fromUuid(spellUuid), fromUuid(reactorUuid), fromUuid(request.sourceTokenUuid)
    ]);
    const actor = reactor?.actor;
    const activity = spell?.system?.activities?.get("weavebendCast001");
    const {actorUtils, genericUtils, tokenUtils} = chrisPremades.utils;
    const {FRIENDLY, HOSTILE} = CONST.TOKEN_DISPOSITIONS;
    const enemies = (reactor?.disposition === FRIENDLY && source?.disposition === HOSTILE)
        || (reactor?.disposition === HOSTILE && source?.disposition === FRIENDLY);
    if (!activity || !actor || genericUtils.getIdentifier(spell) !== "weavebendCustom" || actor.uuid !== spell.actor?.uuid
        || !enemies || !reactor.object || !source?.object || reactor.parent.id !== source.parent.id
        || tokenUtils.getDistance(reactor.object, source.object) > 60 || !tokenUtils.canSee(reactor.object, source.object)
        || actorUtils.hasUsedReaction(actor) || MidiQOL.checkIncapacitated(actor, false, false) || casting.has(actor.uuid)) {
        return false;
    }
    const slot = actor.system.spells?.[slotKey];
    const level = slotKey === "pact" ? Number(slot?.level) : Number(slotKey.match(/^spell([1-9])$/)?.[1]);
    if (activity.requiresSpellSlot ? !(slot?.value > 0 && level >= spell.system.level) : slotKey !== "innate") return false;

    const saved = Array.from(game.user.targets, token => token.id);
    casting.add(actor.uuid);
    try {
        const result = await activity.use({
            spell: slotKey === "innate" ? undefined : {slot: slotKey},
            consume: {spellSlot: slotKey !== "innate", resources: true},
            midiOptions: {
                targetsToUse: new Set([reactor.object]),
                workflowOptions: {
                    forceCompletion: true, noProvokeReaction: true, weavebendRequest: {...request, managed: true}
                }
            }
        }, {configure: false});
        return Boolean(result);
    } finally {
        casting.delete(actor.uuid);
        const targets = game.user.targets;
        if (!targets.size || (targets.size === 1 && targets.has(reactor.object))) game.user.updateTokenTargets(saved);
    }
}

async function castManagedWeavebend(payload) {
    const gm = game.users.activeGM;
    if (!gm?.active) return false;
    if (game.user.id === gm.id) return castOnGM(payload);
    return socket?.executeAsUser("castMachinationsWeavebend", gm.id, payload);
}

Hooks.once("socketlib.ready", () => {
    socket = globalThis.socketlib?.registerModule(moduleId);
    socket?.register("castMachinationsWeavebend", castOnGM);
});
Hooks.once("ready", () => {
    const mod = game.modules.get(moduleId);
    mod.api = {...mod.api, castManagedWeavebend};
});
