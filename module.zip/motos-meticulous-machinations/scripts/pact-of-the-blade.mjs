import {buttons, promptSession} from "./prompts.mjs";
import {isPactWeapon} from "./pact-weapon.mjs";

const cpr = "chris-premades";
const featureId = "pactOfTheBladeCustom";
const savedDamageFlag = "config.pactWeaponDamage";
const rememberSetting = "rememberDamageType";
const normal = "normal";
let registered = false;

const rememberDamage = feature => chrisPremades.utils.itemUtils.getConfig(feature, rememberSetting) !== false;
const damageLabel = type => CONFIG.DND5E.damageTypes[type]?.label ?? "Normal weapon damage";

function configuredTypes(feature) {
    const types = chrisPremades.utils.itemUtils.getConfig(feature, "damageTypes") ?? [];
    return types.filter(type => CONFIG.DND5E.damageTypes[type]);
}

function pactAttack(feature, workflow) {
    return !workflow.aborted && workflow.actor === feature.actor && isPactWeapon(workflow.item) &&
        chrisPremades.utils.workflowUtils.isAttackType(workflow, "attack");
}

function applyPactAbility({trigger: {entity: feature}, workflow}) {
    if (!pactAttack(feature, workflow) || !workflow.activity?.attack) return;
    const {actorUtils, itemUtils} = chrisPremades.utils;
    const pactAbility = itemUtils.getConfig(feature, "ability");
    if (!workflow.actor.system.abilities[pactAbility]) return;
    const weaponAbility = workflow.activity.attack.ability ?? "str";
    const abilities = [pactAbility, weaponAbility];
    if (workflow.item.system.properties.has("fin")) abilities.push("dex");
    if (actorUtils.getBestAbility(workflow.actor, abilities) === weaponAbility) return;

    const activity = workflow.activity.clone({"attack.ability": pactAbility}, {keepId: true});
    activity.prepareData();
    activity.prepareFinalData();
    workflow.activity = activity;
}

function damageChoices(types) {
    return [...types.map(type => [damageLabel(type), type]), [damageLabel(normal), normal]];
}

async function setPactDamage({workflow}) {
    const feature = workflow.item;
    if (workflow.aborted) return;
    if (!rememberDamage(feature)) {
        ui.notifications.info("Enable Remember Pact Weapon Damage in the Medkit to use this activity.");
        return;
    }
    const phase = workflow.currentAction;
    const valid = () => !workflow.aborted && workflow.currentAction === phase &&
        feature.actor.items.get(feature.id)?.flags?.[cpr]?.info?.identifier === featureId && rememberDamage(feature);
    const current = damageLabel(feature.getFlag(cpr, savedDamageFlag));
    const selection = await buttons(promptSession(feature.actor, valid), "Set Pact Weapon Damage",
        `<section style="padding:16px;border:1px solid #a68cce;border-radius:12px;background:#241b35;color:#f3eaff;line-height:1.5;overflow-wrap:anywhere">
            <h2 style="color:#d6bef9;border:0;margin:0 0 8px">Choose the Blade's Damage</h2>
            <p>Current choice: <strong>${foundry.utils.escapeHTML(current)}</strong>.</p>
            <p>Your pact weapon will use this choice until you use this activity again.</p>
        </section>`,
        [...damageChoices(configuredTypes(feature)), ["Cancel", "cancel"]]);
    if (!valid() || (selection !== normal && !configuredTypes(feature).includes(selection))) return;
    await chrisPremades.utils.genericUtils.setFlag(feature, cpr, savedDamageFlag, selection);
}

async function applyPactDamage({trigger: {entity: feature}, workflow}) {
    if (!pactAttack(feature, workflow) || !workflow.damageRolls?.length) return;
    let type;
    if (rememberDamage(feature)) {
        type = feature.getFlag(cpr, savedDamageFlag);
    } else {
        const types = configuredTypes(feature);
        if (types.length < 2) type = types[0];
        else {
            const phase = workflow.currentAction;
            const valid = () => workflow.currentAction === phase && pactAttack(feature, workflow) && !rememberDamage(feature);
            type = await buttons(promptSession(workflow.actor, valid), feature.name, "Choose the pact weapon's damage for this attack.",
                damageChoices(types));
            if (!valid() || !configuredTypes(feature).includes(type)) return;
        }
    }
    if (!type || type === normal || !CONFIG.DND5E.damageTypes[type]) return;
    const rolls = workflow.damageRolls;
    for (const roll of rolls) roll.options.type = type;
    await workflow.setDamageRolls(rolls);
}

function registerPactBlade() {
    if (registered) return;
    const macroUtils = globalThis.chrisPremades?.utils?.macroUtils;
    const original = macroUtils?.getMacro("pactOfTheBlade", "modern");
    if (!original?.midi?.item) return;
    macroUtils.registerMacros([{
        identifier: featureId, name: original.name, version: "1.0", rules: "modern",
        midi: {
            item: [...original.midi.item,
                {pass: "rollFinished", activities: ["setPactDamage"], macro: setPactDamage, priority: 50}],
            actor: [
                {pass: "preambleComplete", macro: applyPactAbility, priority: 25},
                {pass: "damageRollComplete", macro: applyPactDamage, priority: 25}
            ]
        },
        config: [...(original.config ?? []), {
            value: rememberSetting, label: "Remember Pact Weapon Damage", type: "checkbox", default: true, category: "mechanics"
        }]
    }]);
    registered = true;
}

Hooks.once("cprReady", registerPactBlade);
Hooks.once("ready", registerPactBlade);
