export async function offerNobleSacrifice(recipient, reason, options) {
let {activityUtils, actorUtils, dialogUtils, genericUtils, socketUtils, tokenUtils} = globalThis.chrisPremades.utils;
let nobleId = "nobleSacrifice";
let nobleEscape = value => foundry.utils.escapeHTML(String(value ?? ""));
let nobleWindow = actor => actor.flags["chris-premades"]?.nobleSacrificeWindow;
function noblePanel(title, body) {
    return `<style>
    .application:has(.noble-sacrifice-dialog){width:min(495px,calc(100vw - 32px))!important;min-width:0!important;max-height:90vh}
    .application:has(.noble-sacrifice-dialog) .window-content{overflow:auto;min-width:0}
    .application:has(.noble-sacrifice-dialog) button{white-space:normal;overflow-wrap:anywhere;min-height:39px;height:auto}
    </style><section class="noble-sacrifice-dialog" style="border:1px solid #c2a26c;border-radius:12px;padding:18px;background:radial-gradient(ellipse at top right,#584132,#352128 65%,#1e1a28);color:#faede4;line-height:1.5;overflow-wrap:anywhere">
    <h2 style="border:0;color:#f3d79d;margin:0 0 10px">${title}</h2>${body}</section>`;
}
function nobleCanReach(caster, recipient) {
    if (!caster?.actor || !recipient?.actor || caster.actor.uuid === recipient.actor.uuid) return false;
    if (caster.document.parent?.uuid !== recipient.document.parent?.uuid) return false;
    let disposition = caster.document.disposition;
    if (Math.abs(disposition) !== 1 || disposition !== recipient.document.disposition) return false;
    let distance = tokenUtils.getDistance(caster, recipient);
    return Number.isFinite(distance) && distance >= 0 && distance <= 30 && tokenUtils.canSee(caster, recipient);
}
function nobleCanCast(caster, activity, recipient) {
    if (!nobleCanReach(caster, recipient) || !activityUtils.canUse(activity) || caster.actor.system.attributes.hp.value <= 0) return false;
    if (actorUtils.hasUsedReaction(caster.actor) || MidiQOL.checkIncapacitated(caster.actor, false, false)) return false;
    let spell = activity.item;
    if (caster.actor.type === "character" && CONFIG.DND5E.spellcasting[spell.system.method]?.prepares && spell.system.prepared === 0) return false;
    if (!activity.consumption.spellSlot || !activity.requiresSpellSlot) return true;
    return Object.entries(caster.actor.system.spells ?? {}).some(([key, slot]) => {
        let level = key === "pact" ? Number(slot.level) : Number(key.replace(/^spell/, ""));
        return level >= spell.system.level && slot.value > 0;
    });
}

async function nobleOffer(recipient, reason, {verifiedTransition = false} = {}) {
    let victim = recipient?.actor;
    if (!victim || victim.system.attributes.hp.value !== 0) return false;
    if (reason === "dropped" && !verifiedTransition && (victim.statuses.has("dead") || victim.system.attributes.death?.failure >= 3)) return false;
    let key = Symbol.for("world.nobleSacrifice.pending");
    let pending = globalThis[key] ??= new Map();
    if (pending.has(victim.uuid)) return pending.get(victim.uuid);
    let task = nobleResolveOffers(recipient, reason);
    pending.set(victim.uuid, task);
    try {
        return await task;
    } catch (error) {
        console.error("Noble Sacrifice reaction failed", error);
        return victim.system.attributes.hp.value > 0;
    } finally {
        pending.delete(victim.uuid);
    }
}
async function nobleResolveOffers(recipient, reason) {
    let victim = recipient.actor;
    let scene = recipient.document.parent;
    let existing = nobleWindow(victim);
    if (existing?.expiresAt > Date.now()) {
        while (victim.system.attributes.hp.value === 0 && nobleWindow(victim)?.id === existing.id && Date.now() < existing.expiresAt) {
            await genericUtils.sleep(200);
        }
        return victim.system.attributes.hp.value > 0;
    }
    let candidates = [];
    for (let doc of scene.tokens) {
        let token = doc.object;
        if (!token?.actor?.items || doc.disposition !== recipient.document.disposition) continue;
        let item = token.actor.items.find(spell => spell.type === "spell" && spell.flags["chris-premades"]?.info?.identifier === nobleId);
        let activity = item?.system.activities.get("utilityNobleSacr");
        if (!activity || !nobleCanCast(token, activity, recipient)) continue;
        let owner = game.users.get(socketUtils.firstOwner(token.actor, true));
        if (!owner?.active || (owner.viewedScene && owner.viewedScene !== scene.id)) {
            owner = game.users.get(socketUtils.gmID());
        }
        if (!owner?.active || (owner.viewedScene && owner.viewedScene !== scene.id)) continue;
        candidates.push({token, activity, owner, distance: tokenUtils.getDistance(token, recipient)});
    }
    candidates.sort((a, b) => a.distance - b.distance);
    if (!candidates.length) return false;
    let window = {id: foundry.utils.randomID(), targetUuid: recipient.document.uuid, reason, expiresAt: Date.now() + 120000};
    await genericUtils.setFlag(victim, "chris-premades", "nobleSacrificeWindow", window);
    if (nobleWindow(victim)?.id !== window.id) return victim.system.attributes.hp.value > 0;
    try {
        let offered = new Set();
        for (let {token, activity, owner} of candidates) {
            if (victim.system.attributes.hp.value > 0) return true;
            if (nobleWindow(victim)?.id !== window.id || Date.now() >= window.expiresAt) break;
            if (offered.has(token.actor.uuid) || !nobleCanCast(token, activity, recipient)) continue;
            offered.add(token.actor.uuid);
            let loss = Math.floor(token.actor.system.attributes.hp.value / 2);
            let event = {
                dropped: "has just dropped to 0 HP",
                damage: "has reached three death-save failures from damage",
                roll: "has just failed their third death save",
                failure: "has just reached three death-save failures"
            }[reason];
            let answer = await dialogUtils.buttonDialog("Noble Sacrifice - Reaction", noblePanel("Give of Your Life",
                `<p><strong>${nobleEscape(recipient.name)}</strong> ${event}.</p><p>Use <strong>${nobleEscape(token.name)}'s Reaction</strong> to cast Noble Sacrifice and restore them to <strong>1 HP</strong>. At your current HP, the sacrifice is <strong>${loss} HP</strong>. Your temporary HP stays available.</p>`),
            [["Cast Noble Sacrifice", "cast"], ["Decline", "decline"]], {userId: owner.id});
            if (answer !== "cast" || !nobleCanCast(token, activity, recipient) || victim.system.attributes.hp.value !== 0
                || nobleWindow(victim)?.id !== window.id || Date.now() >= window.expiresAt) continue;
            await genericUtils.setFlag(victim, "chris-premades", "nobleSacrificeWindow", {...window, casterUuid: token.actor.uuid});
            try {
                await MidiQOL.completeActivityUse(activity.uuid, {midiOptions: {
                    asUser: owner.id, targetUuids: [recipient.document.uuid], configureDialog: true,
                    workflowOptions: {nobleSacrificeRequest: {id: window.id, targetUuid: window.targetUuid}, targetConfirmation: "none"}
                }}, {configure: true});
            } catch (error) {
                console.error("Noble Sacrifice reaction cast", error);
            }
        }
        return victim.system.attributes.hp.value > 0;
    } finally {
        if (nobleWindow(victim)?.id === window.id) await genericUtils.unsetFlag(victim, "chris-premades", "nobleSacrificeWindow");
    }
}

return await nobleOffer(recipient, reason, options);
}
