export async function runFaithfulSteed(phase, {workflow, trigger, ditem, actor} = {}) {
let {actorUtils, dialogUtils, effectUtils, genericUtils, itemUtils, socketUtils, tokenUtils, workflowUtils} = globalThis.chrisPremades.utils;
let {Crosshairs} = globalThis.chrisPremades;
let bondKey = "faithfulSteedBond";
let bondPath = "flags.world." + bondKey;
let forms = {
    celestial: {damage: "radiant", power: "faithfulSteedHealingTouch", label: "Celestial", ability: "Healing Touch"},
    fey: {damage: "psychic", power: "faithfulSteedFeyStep", label: "Fey", ability: "Fey Step"},
    fiend: {damage: "necrotic", power: "faithfulSteedFellGlare", label: "Fiend", ability: "Fell Glare"}
};
let findSteedId = "faithfulSteedSpell";
let findSteedActivity = "faithfulSteedUse";
let bondIdentifier = "faithfulSteed";
let state = subject => subject?.flags?.world?.[bondKey] ?? {};
let health = subject => subject?.system?.attributes?.hp;
let cprItem = (subject, identifier) => subject?.items.find(item => item.flags["chris-premades"]?.info?.identifier === identifier);
let active = mount => state(mount).manifested && health(mount)?.value > 0;
let string = value => foundry.utils.escapeHTML(String(value ?? ""));
let gmId = () => game.users.activeGM?.id ?? socketUtils.gmID();
let playerId = subject => socketUtils.firstOwner(subject, true) || gmId();
let registerLocks = () => globalThis[Symbol.for("world.faithfulSteedLocks")] ??= new Set();
let dead = subject => subject?.statuses.has("dead") || (health(subject)?.value === 0 && subject.system.attributes.death?.failure >= 3);
let placed = (subject, scene) => scene?.tokens.filter(doc => doc.actorLink && doc.actorId === subject.id) ?? [];
let tokenOnScene = (subject, scene) => placed(subject, scene).find(doc => !doc.hidden)?.object;
let riderIds = steedDoc => steedDoc.flags.Rideable?.RidersFlag ?? [];
let rideable = () => game.modules.get("Rideable")?.active && game.Rideable;

function panel(title, body) {
    return `<style>
    .application:has(.faithful-steed-dialog){width:min(500px,calc(100vw - 32px))!important;min-width:0!important;max-height:90vh}
    .application:has(.faithful-steed-dialog) .window-content{min-width:0;overflow:auto}
    .application:has(.faithful-steed-dialog) button{white-space:normal;overflow-wrap:anywhere;min-height:39px}
    </style><section class="faithful-steed-dialog" style="border:1px solid #c6a477;background:linear-gradient(145deg,#3d2d26,#201b2c);border-radius:14px;padding:17px;color:#f4ead8;line-height:1.5"><h2 style="border:0;color:#eccc94;margin:0 0 10px">${title}</h2>${body}</section>`;
}

function choose(subject, title, body, buttons, userId = playerId(subject)) {
    return dialogUtils.buttonDialog("Faithful Steed - " + title, panel(title, body), buttons, {userId});
}

function pendingNotice(title, subject, token, body, gmOnly = false) {
    return ChatMessage.implementation.create({
        speaker: ChatMessage.implementation.getSpeaker({actor: subject, token}),
        content: panel(title, body),
        whisper: gmOnly && gmId() ? [gmId()] : []
    });
}

async function pair(subject) {
    let binding = state(subject);
    let paladin = binding.role === "paladin" ? subject : binding.paladinUuid && await fromUuid(binding.paladinUuid);
    let steed = binding.role === "steed" ? subject : binding.steedUuid && await fromUuid(binding.steedUuid);
    if (!paladin || !steed || state(paladin).steedUuid !== steed.uuid || state(steed).paladinUuid !== paladin.uuid) return {};
    return {paladin, steed};
}

async function withSteedLock(steed, work) {
    let locks = registerLocks();
    if (locks.has(steed.uuid)) return;
    locks.add(steed.uuid);
    try {
        return await work();
    } finally {
        locks.delete(steed.uuid);
    }
}

function getOwnedSpell(paladin) {
    return paladin.items.find(candidate => candidate.type === "spell" &&
        (candidate.system.identifier === "find-steed" || /^find steed$/i.test(candidate.name)) &&
        candidate.system.source.rules === "2024");
}

async function prepareOwnedSpell(paladin, template) {
    let item = getOwnedSpell(paladin);
    if (item && cprItem(paladin, findSteedId)?.id === item.id && item.system.prepared === 2) return item;
    if (!template) return ui.notifications.warn("The persistent Find Steed spell is unavailable.");
    let spell = foundry.utils.deepClone(template);
    delete spell._id;
    delete spell.folder;
    delete spell._stats;
    if (!item) return (await genericUtils.createEmbeddedDocuments(paladin, "Item", [spell]))?.[0];
    await genericUtils.update(item, {
        "system.prepared": 2,
        "system.method": "spell",
        "system.sourceClass": "paladin",
        "system.==activities": spell.system.activities,
        "flags.==chris-premades": spell.flags["chris-premades"],
        "flags.midi-qol.-=onUseMacroName": null
    });
    return item;
}

function spellStats(paladin) {
    let info = paladin.classes?.paladin?.spellcasting;
    let ability = paladin.system.abilities[info?.ability || "cha"];
    let prof = Number(paladin.system.attributes.prof) || 2;
    let bonuses = paladin.system.bonuses?.msak;
    let formula = String(bonuses?.attack || "0");
    let bonus = Number(formula);
    if (!Number.isFinite(bonus)) {
        try {
            let roll = new Roll(formula, paladin.getRollData());
            bonus = roll.isDeterministic ? roll.evaluateSync().total : 0;
        } catch {
            bonus = 0;
        }
    }
    return {prof, attack: Number(ability?.mod ?? 0) + prof + bonus, dc: Number(info?.save ?? ability?.dc ?? (8 + Number(ability?.mod ?? 0) + prof))};
}

async function syncProfile(paladin, steed, {form = state(steed).form, level = state(steed).level, summoned = false} = {}) {
    if (!Object.hasOwn(forms, form)) form = "fey";
    let profile = forms[form];
    level = Math.max(2, Math.min(9, Number(level) || 2));
    let stats = spellStats(paladin);
    let maximum = 5 + 10 * level;
    let hp = health(steed);
    let data = {
        [bondPath + ".form"]: form,
        [bondPath + ".level"]: level,
        "system.details.type.value": form,
        "system.attributes.ac.flat": 10 + level,
        "system.attributes.hp.max": maximum,
        "system.attributes.hp.formula": level + "d10 + " + (5 + 2 * level),
        "system.attributes.hp.value": summoned ? maximum : Math.min(hp.value, maximum),
        "system.attributes.movement.fly": level >= 4 ? "60" : "0",
        "prototypeToken.actorLink": true,
        "prototypeToken.flags.Rideable.issetRideableFlag": true,
        "prototypeToken.flags.Rideable.MaxRiderFlag": 1
    };
    if (summoned) Object.assign(data, {
        [bondPath + ".manifested"]: true,
        "system.attributes.hp.temp": 0,
        "system.attributes.hp.tempmax": null,
        "system.attributes.hd.spent": 0,
        "system.attributes.death.success": 0,
        "system.attributes.death.failure": 0
    });
    let updates = [];
    let slam = cprItem(steed, "faithfulSteedSlam");
    let touch = cprItem(steed, forms.celestial.power);
    let glare = cprItem(steed, forms.fiend.power);
    if (slam) {
        let parts = slam.toObject().system.activities.attackOtSlaction.damage.parts;
        Object.assign(parts[0], {bonus: String(level), types: [profile.damage]});
        updates.push({_id: slam.id, "system.activities.attackOtSlaction.attack.bonus": String(stats.attack),
            "system.activities.attackOtSlaction.damage.parts": parts});
    }
    if (touch) updates.push({_id: touch.id, "system.activities.steedHealTouch01.healing.bonus": String(level)});
    if (glare) updates.push({_id: glare.id, "system.activities.steedFellGlare01.save.dc.formula": String(stats.dc)});
    if (summoned) for (let option of Object.values(forms)) {
        let ability = cprItem(steed, option.power);
        if (!ability) continue;
        let update = updates.find(entry => entry._id === ability.id);
        if (update) update["system.uses.spent"] = 0;
        else updates.push({_id: ability.id, "system.uses.spent": 0});
    }
    let profEffect = steed.effects.find(effect => effect.flags.world?.faithfulSteedProficiency);
    let changes = [{key: "system.attributes.prof", mode: 5, value: String(stats.prof), priority: 50}];
    if (!profEffect) await genericUtils.createEmbeddedDocuments(steed, "ActiveEffect", [{
        name: "Faithful Steed Proficiency", img: "icons/svg/upgrade.svg", transfer: false, changes,
        flags: {world: {faithfulSteedProficiency: true}}
    }]);
    else if (profEffect.changes[0]?.value !== String(stats.prof)) await genericUtils.update(profEffect, {changes});
    let actorChanges = Object.fromEntries(Object.entries(data).filter(([key, value]) => foundry.utils.getProperty(steed, key) !== value));
    if (Object.keys(actorChanges).length) await genericUtils.update(steed, actorChanges);
    updates = updates.map(({_id, ...values}) => {
        let item = steed.items.get(_id).toObject();
        let diff = Object.fromEntries(Object.entries(values).filter(([key, value]) => {
            let current = foundry.utils.getProperty(item, key);
            if (Array.isArray(value)) return JSON.stringify(current) !== JSON.stringify(value);
            return current !== value;
        }));
        return Object.keys(diff).length ? {_id, ...diff} : null;
    }).filter(Boolean);
    if (updates.length) await genericUtils.updateEmbeddedDocuments(steed, "Item", updates);
}

async function chooseForm(paladin, steed, title) {
    let current = forms[state(steed).form]?.label ?? "Fey";
    return choose(paladin, title,
        `<p>Choose the form for <strong>${string(steed.name)}</strong>. Its current form is <strong>${current}</strong>.</p><p>The form changes its creature type, Slam damage, and available special ability.</p>`,
        Object.entries(forms).map(([key, form]) => [form.label + " (" + form.ability + ")", key]).concat([["Cancel", "cancel"]]));
}

async function bind(paladin, template) {
    if (paladin.isToken) return ui.notifications.warn("Bind from a sidebar Paladin or a linked Paladin token.");
    let prior = state(paladin).steedUuid && await fromUuid(state(paladin).steedUuid);
    let choices = game.actors.filter(candidate => candidate.type === "npc" && state(candidate).role === "steed" &&
        (!state(candidate).paladinUuid || state(candidate).paladinUuid === paladin.uuid) && (!prior || candidate.uuid === prior.uuid));
    if (!choices.length) return ui.notifications.warn("Import the automated Otherworldly Steed actor before binding.");
    let steed = await dialogUtils.selectDocumentDialog("Bind Permanent Steed",
        panel("One Rider, One Steed", "<p>Choose the sidebar actor to carry the same bond, inventory and HP between scenes. Cast Find Steed afterward to summon it.</p>"),
        choices, {userId: playerId(paladin)});
    if (!steed) return;
    await withSteedLock(steed, async () => {
        if (state(steed).paladinUuid && state(steed).paladinUuid !== paladin.uuid) return;
        let ownership = {...steed.ownership};
        for (let [id, permission] of Object.entries(paladin.ownership)) if (id !== "default" && permission === 3) ownership[id] = 3;
        await genericUtils.update(steed, {ownership, [bondPath + ".paladinUuid"]: paladin.uuid, "prototypeToken.actorLink": true});
        await genericUtils.update(paladin, {[bondPath]: {role: "paladin", steedUuid: steed.uuid}});
        await prepareOwnedSpell(paladin, template);
        await syncProfile(paladin, steed);
        ui.notifications.info(steed.name + " is bound to " + paladin.name + ".");
    });
}

async function showOnScene(steed, scene) {
    let updates = placed(steed, scene).filter(doc => doc.hidden && state(doc).hiddenByBond)
        .map(doc => ({_id: doc.id, hidden: false, [bondPath + ".hiddenByBond"]: false}));
    if (updates.length) await genericUtils.updateEmbeddedDocuments(scene, "Token", updates);
}

async function setInitiative(paladin, steed, scene, {add = false} = {}) {
    let combat = game.combat;
    if (!scene || combat?.scene?.id !== scene.id) return;
    let paladinTurn = combat.combatants.find(entry => entry.actor?.uuid === paladin.uuid);
    if (!paladinTurn || paladinTurn.initiative === null) return;
    let doc = placed(steed, scene).find(entry => !entry.hidden);
    if (!doc) return;
    let turn = combat.combatants.find(entry => entry.tokenId === doc.id);
    if (!turn && add) [turn] = await genericUtils.createEmbeddedDocuments(combat, "Combatant", [{tokenId: doc.id, actorId: steed.id, sceneId: scene.id, initiative: paladinTurn.initiative}]);
    if (turn && (turn.initiative !== paladinTurn.initiative || turn.defeated)) {
        await genericUtils.update(turn, {initiative: paladinTurn.initiative, defeated: false});
    }
}

async function refresh(paladin, paladinToken, template) {
    let {steed} = await pair(paladin);
    if (!steed) return ui.notifications.warn("Use Bind Permanent Steed first.");
    await dismissWhenNeeded(paladin);
    let form = await chooseForm(paladin, steed, "Refresh the Bond");
    if (!Object.hasOwn(forms, form)) return;
    await withSteedLock(steed, async () => {
        await prepareOwnedSpell(paladin, template);
        await syncProfile(paladin, steed, {form});
        if (active(steed) && paladinToken?.document.parent) {
            await showOnScene(steed, paladinToken.document.parent);
            await setInitiative(paladin, steed, paladinToken.document.parent);
        }
        ui.notifications.info(steed.name + " is refreshed in " + forms[form].label + " form.");
    });
}

function destination(point, doc, ignoredIds, radius, origin) {
    let dimensions = canvas.dimensions;
    let size = canvas.grid.size;
    if (!Number.isFinite(point?.x) || !Number.isFinite(point?.y)) return;
    let width = doc.width * size;
    let height = doc.height * size;
    let corner = canvas.grid.getSnappedPoint({x: point.x - width / 2, y: point.y - height / 2}, {mode: CONST.GRID_SNAPPING_MODES.TOP_LEFT_CORNER});
    let center = {x: corner.x + width / 2, y: corner.y + height / 2};
    let distance = canvas.grid.measurePath([origin, center]).distance;
    let sceneRect = dimensions.sceneRect;
    if (distance > radius + 0.01 || corner.x < sceneRect.x || corner.y < sceneRect.y ||
        corner.x + width > sceneRect.x + sceneRect.width || corner.y + height > sceneRect.y + sceneRect.height) return;
    if (canvas.tokens.placeables.some(candidate => !ignoredIds.has(candidate.id) &&
        Math.abs(candidate.document.elevation - doc.elevation) < 0.01 &&
        corner.x < candidate.x + candidate.w && corner.x + width > candidate.x &&
        corner.y < candidate.y + candidate.h && corner.y + height > candidate.y)) return;
    return {x: corner.x, y: corner.y, elevation: doc.elevation};
}

async function pickPosition(token, doc, ignoredIds, radius, icon, label) {
    if (!canvas.ready || token.document.parent.id !== canvas.scene.id) {
        ui.notifications.warn("Open the scene containing the acting token first.");
        return;
    }
    let point = await Crosshairs.showCrosshairs({size: doc.width, icon, label});
    if (point?.cancelled) return;
    let position = destination(point, doc, ignoredIds, radius, token.center);
    if (!position) ui.notifications.warn("Choose an unoccupied space within " + radius + " feet.");
    return position;
}

async function animate(item, token, field) {
    if (!token?.object && !token?.document) return;
    if (!game.modules.get("sequencer")?.active || !itemUtils.getConfig(item, "playAnimation")) return;
    let file = itemUtils.getConfig(item, field);
    try {
        if (!file || (file.startsWith("jb2a.") && !Sequencer.Database.entryExists(file))) return;
        await new Sequence().effect().file(file).atLocation(token.object ?? token).scaleToObject(1.5).play();
    } catch (error) {
        console.warn("Faithful Steed animation", error);
    }
}

async function dismissWhenNeeded(subject) {
    let binding = state(subject);
    if (binding.role !== "steed" && binding.role !== "paladin") return;
    let {paladin, steed} = await pair(subject);
    if (!steed || !state(steed).manifested || (health(steed).value > 0 && !dead(paladin))) return;
    await withSteedLock(steed, async () => {
        if (!state(steed).manifested || (health(steed).value > 0 && !dead(paladin))) return;
        await genericUtils.update(steed, {[bondPath + ".manifested"]: false});
        for (let scene of game.scenes) {
            let docs = placed(steed, scene);
            for (let doc of docs) if (riderIds(doc).length && rideable()) game.Rideable.UnMountallRiders(doc);
            let updates = docs.filter(doc => !doc.hidden).map(doc => ({_id: doc.id, hidden: true, [bondPath + ".hiddenByBond"]: true}));
            if (updates.length) await genericUtils.updateEmbeddedDocuments(scene, "Token", updates);
            for (let combat of game.combats.filter(entry => entry.scene?.id === scene.id)) {
                let defeated = combat.combatants.filter(entry => docs.some(doc => doc.id === entry.tokenId) && !entry.defeated);
                if (defeated.length) await genericUtils.updateEmbeddedDocuments(combat, "Combatant", defeated.map(entry => ({_id: entry.id, defeated: true})));
            }
        }
        if (steed.items.some(item => item.system.equipped || item.system.quantity)) {
            await pendingNotice("The Steed Vanishes", steed, null, "<p>The steed's carried equipment is left at the location it vanished. Move any carried items to the scene manually.</p>", true);
        }
    });
}

async function reviewWounds(steed) {
    let harmful = new Set(["dead", "bleeding-out", "stable", "unconscious", "poisoned", "prone", "restrained",
        "charmed", "frightened", "blinded", "deafened", "grappled", "incapacitated", "paralyzed", "petrified", "stunned", "exhaustion"]);
    let effects = steed.effects.filter(effect => !effect.disabled && !effect.flags.world?.faithfulSteedProficiency);
    let preselected = {};
    for (let effect of effects) {
        if (!Array.from(effectUtils.getConditions(effect)).some(status => harmful.has(status)) && !/^(bleeding out|stable|dead)$/i.test(effect.name)) continue;
        preselected[effect.id] = true;
        let uuid = effect.flags.dnd5e?.dependentOn ?? effect.flags["chris-premades"]?.parentEntityUuid;
        let parent = uuid && await fromUuid(uuid);
        if (parent?.documentName !== "ActiveEffect" || parent.parent?.uuid !== steed.uuid || parent.statuses.has("concentrating") || /concentrat/i.test(parent.name)) continue;
        if (!effects.some(entry => entry.id === parent.id)) effects.push(parent);
        preselected[parent.id] = true;
    }
    let rows = effects.map(effect => ({id: effect.id, document: {name: effect.name, texture: {src: effect.img}}}));
    if (steed.system.attributes.exhaustion > 0) {
        rows.push({id: "exhaustion", document: {name: "Exhaustion", texture: {src: "icons/svg/downgrade.svg"}}});
        preselected.exhaustion = true;
    }
    if (!rows.length) return [];
    if (!game.users.get(gmId())?.active) {
        ui.notifications.warn("An active GM is needed to review the steed's effects.");
        return;
    }
    let answer = await dialogUtils.selectTargetDialog("Renew the Steed - GM Review",
        panel("Shed the Wounds of Battle", "<p>Choose which effects to clear on summoning. Familiar harmful effects are selected. Cancel stops this cast before spending its resource.</p>"),
        rows, {type: "multiple", skipDeadAndUnconscious: false, preselected, displayDistance: false, userId: gmId()});
    return answer?.[0]?.map(row => row.id) ?? (answer ? [] : undefined);
}

async function planSummon(workflow) {
    if (workflow.activity.id !== findSteedActivity) return;
    let paladin = workflow.actor;
    let {steed} = await pair(paladin);
    if (!steed || !workflow.token?.document) {
        ui.notifications.warn("Use Bind Permanent Steed and enter the scene with a linked Paladin token.");
        return true;
    }
    let free = workflow.workflowOptions?.faithfulSteedFree === true;
    let feature = cprItem(paladin, bondIdentifier);
    if (free && !(feature?.system.uses.value > 0)) {
        ui.notifications.warn("The Faithful Steed free cast has already been spent.");
        return true;
    }
    let scene = workflow.token.document.parent;
    if (placed(steed, scene).length > 1) {
        ui.notifications.warn("Keep one linked steed token per scene before summoning.");
        return true;
    }
    let form = await chooseForm(paladin, steed, "Call Your Steed");
    if (!Object.hasOwn(forms, form)) return true;
    let footprint = {width: 2, height: 2, elevation: workflow.token.document.elevation};
    let ignored = new Set(placed(steed, scene).map(doc => doc.id));
    let position = await pickPosition(workflow.token, footprint, ignored, 30, steed.img, "Where should the steed appear?");
    if (!position) return true;
    let removals = await reviewWounds(steed);
    if (!removals) return true;
    workflow.faithfulSteedSummon = {steedUuid: steed.uuid, form, position, sceneId: scene.id, removals, free, footprint};
}

async function finishSummon(workflow) {
    if (workflow.aborted || !workflow.faithfulSteedSummon || workflow.faithfulSteedSummoned) return;
    workflow.faithfulSteedSummoned = true;
    let {steed} = await pair(workflow.actor);
    let plan = workflow.faithfulSteedSummon;
    let scene = workflow.token.document.parent;
    if (steed?.uuid !== plan.steedUuid || scene.id !== plan.sceneId) return;
    await withSteedLock(steed, async () => {
        let feature = cprItem(workflow.actor, bondIdentifier);
        if (plan.free && !(feature?.system.uses.value > 0)) return;
        let [existing] = placed(steed, scene);
        if (existing && riderIds(existing).length && rideable()) game.Rideable.UnMountallRiders(existing);
        if (plan.removals.includes("exhaustion")) await genericUtils.update(steed, {"system.attributes.exhaustion": 0});
        let clear = plan.removals.filter(id => steed.effects.has(id));
        if (clear.length) await genericUtils.deleteEmbeddedDocuments(steed, "ActiveEffect", clear);
        let level = plan.free ? 2 : workflowUtils.getCastLevel(workflow);
        await syncProfile(workflow.actor, steed, {form: plan.form, level, summoned: true});
        let data = {...plan.position, width: 2, height: 2, actorLink: true, hidden: false, disposition: workflow.token.document.disposition,
            [bondPath + ".hiddenByBond"]: false};
        if (existing) {
            await genericUtils.updateEmbeddedDocuments(scene, "Token", [{_id: existing.id, ...data}]);
        } else {
            let created = (await steed.getTokenDocument(data)).toObject();
            delete created._id;
            [existing] = await genericUtils.createEmbeddedDocuments(scene, "Token", [created]);
        }
        if (plan.free) await genericUtils.update(feature, {"system.uses.spent": (feature.system.uses.spent ?? 0) + 1});
        await setInitiative(workflow.actor, steed, scene, {add: true});
        void animate(workflow.item, existing, "summonAnimation");
        await pendingNotice("The Bond Rekindles", workflow.actor, workflow.token,
            `<p><strong>${string(steed.name)}</strong> arrives at full HP in ${forms[plan.form].label} form. It uses a level ${Math.max(2, Number(level) || 2)} stat block.</p>`);
    });
}

async function toggleMount(paladin, token) {
    let {steed} = await pair(paladin);
    let mount = steed && token?.document && tokenOnScene(steed, token.document.parent);
    if (!mount || !active(steed)) return ui.notifications.warn("Your living steed and Paladin must be on the same scene.");
    if (!rideable()) return ui.notifications.warn("Enable Rideable to use Mount / Dismount.");
    let riding = riderIds(mount.document).includes(token.id);
    let reach = () => {
        let distance = tokenUtils.getDistance(token, mount);
        return distance >= 0 && distance <= 5;
    };
    if (!riding && (actorUtils.getSize(steed) <= actorUtils.getSize(paladin) || !reach())) {
        return ui.notifications.warn("You must be within 5 feet of a steed at least one size larger.");
    }
    let action = riding ? "Dismount" : "Mount";
    let selection = await choose(paladin, action + " Your Steed",
        `<p>${action} <strong>${string(steed.name)}</strong> using Rideable. Apply the normal mounting movement cost at the table.</p>`,
        [[action, "yes"], ["Cancel", "cancel"]]);
    if (selection !== "yes" || !active(steed)) return;
    if (riding) game.Rideable.UnMount([token.document]);
    else if (reach()) game.Rideable.Mount([token.document], mount.document, {});
    await setInitiative(paladin, steed, token.document.parent);
}

async function freeCast(workflow) {
    let held = cprItem(workflow.actor, findSteedId);
    let activity = held?.system.activities.get(findSteedActivity);
    if (!activity) return ui.notifications.warn("Use Bind Permanent Steed or Refresh Bond to prepare the persistent Find Steed spell.");
    if (!(workflow.item.system.uses.value > 0)) return ui.notifications.warn("The free Find Steed cast returns on a Long Rest.");
    await MidiQOL.completeActivityUse(activity, {consume: {spellSlot: false, resources: false},
        midiOptions: {workflowOptions: {faithfulSteedFree: true, targetConfirmation: "none"}}}, {configure: false});
}

async function featureUse(workflow, template) {
    if (workflow.aborted) return;
    let actor = workflow.actor;
    if (workflow.activity.id === "steedBindBond001") return bind(actor, template);
    if (workflow.activity.id === "steedRefresh0001") return refresh(actor, workflow.token, template);
    if (workflow.activity.id === "steedMount000001") return toggleMount(actor, workflow.token);
    if (workflow.activity.id === "steedFreeCast001") return freeCast(workflow);
}

function recordHealing(workflow, token, damage) {
    if (workflow.item?.type !== "spell" || !token?.actor || state(token.actor).role !== "paladin" ||
        workflowUtils.getCastLevel(workflow) < 1 || !(damage?.newHP > damage?.oldHP)) return;
    workflow.faithfulSteedHealing ??= new Map();
    workflow.faithfulSteedHealing.set(token.document.uuid, {old: damage.oldHP, gain: damage.newHP - damage.oldHP});
}

async function resolveHealing(workflow, token) {
    let entry = token?.document && workflow.faithfulSteedHealing?.get(token.document.uuid);
    if (!entry || workflow.aborted) return;
    workflow.faithfulSteedHealing.delete(token.document.uuid);
    let {steed} = await pair(token.actor);
    if (!active(steed)) return;
    let target = tokenOnScene(steed, token.document.parent);
    if (!target) return;
    let distance = tokenUtils.getDistance(token, target);
    if (distance < 0 || distance > 5) return;
    let gain = Math.min(entry.gain, health(token.actor).value - entry.old, health(steed).max - health(steed).value);
    if (gain <= 0) return;
    await genericUtils.update(steed, {"system.attributes.hp.value": health(steed).value + gain});
    let lifeBond = cprItem(steed, "faithfulSteedLifeBond");
    if (lifeBond) void animate(lifeBond, target, "effectAnimation");
    await pendingNotice("Life Bond", steed, target, `<p><strong>${string(steed.name)}</strong> regains ${gain} HP through the bond.</p>`);
}

async function powerGuard(workflow, form) {
    let {paladin, steed} = await pair(workflow.actor);
    if (!paladin || !active(steed)) {
        ui.notifications.warn("Bind and summon the steed before using its abilities.");
        return true;
    }
    if (form && state(steed).form !== form) {
        ui.notifications.warn(forms[form].ability + " requires " + forms[form].label + " form.");
        return true;
    }
    if (form && Object.values(forms).some(entry => cprItem(steed, entry.power)?.system.uses.spent > 0)) {
        ui.notifications.warn("The steed's special ability has already been used since its last Long Rest or summon.");
        return true;
    }
    if (!form && !MidiQOL.checkIncapacitated(paladin, false, false) && workflow.token?.document) {
        let rider = riderIds(workflow.token.document).map(id => workflow.token.document.parent.tokens.get(id));
        if (rider.some(doc => doc?.actor?.uuid === paladin.uuid)) {
            ui.notifications.warn("A controlled steed can Dash, Disengage, or Dodge with its Action. Dismount to use Otherworldly Slam.");
            return true;
        }
    }
    if (form === "fiend") {
        let target = workflow.targets.first();
        let distance = target && workflow.token && tokenUtils.getDistance(workflow.token, target);
        if (workflow.targets.size !== 1 || !workflow.token || distance < 0 || distance > 60 || !tokenUtils.canSee(workflow.token, target)) {
            ui.notifications.warn("Choose a visible creature within 60 feet for Fell Glare.");
            return true;
        }
    }
    if (form === "fiend" || !form) await syncProfile(paladin, steed);
    if (form === "fey") {
        let token = workflow.token;
        if (!token?.document) return true;
        let doc = token.document;
        let riders = riderIds(doc);
        let position = await pickPosition(token, doc, new Set([doc.id, ...riders]), 60, steed.img, "Where should the steed reappear?");
        if (!position) return true;
        workflow.faithfulSteedStep = {position, riders, sceneId: doc.parent.id};
    }
}

async function finishPower(workflow, form) {
    if (workflow.aborted) return;
    let token = workflow.token;
    if (form === "fey" && workflow.faithfulSteedStep && token?.document) {
        let {position, riders, sceneId} = workflow.faithfulSteedStep;
        let doc = token.document;
        if (doc.parent.id !== sceneId) return;
        let dx = position.x - doc.x, dy = position.y - doc.y;
        let updates = [{_id: doc.id, ...position}];
        let movement = {[doc.id]: {waypoints: [{...position, action: "blink"}], autoRotate: false}};
        for (let id of riders.filter(id => riderIds(doc).includes(id))) {
            let rider = doc.parent.tokens.get(id);
            if (!rider) continue;
            let end = {x: rider.x + dx, y: rider.y + dy, elevation: rider.elevation};
            updates.push({_id: id, ...end});
            movement[id] = {waypoints: [{...end, action: "blink"}], autoRotate: false};
        }
        await genericUtils.updateEmbeddedDocuments(doc.parent, "Token", updates, {movement});
        void animate(workflow.item, token, "effectAnimation");
    } else if (form === "fiend") {
        let {paladin} = await pair(workflow.actor);
        if (!paladin) return;
        let combat = game.combat;
        let tracked = Boolean(combat?.started && combat.combatants.some(entry => entry.actor?.uuid === paladin.uuid));
        for (let target of workflow.failedSaves ?? []) {
            if (!target.actor || actorUtils.checkTrait(target.actor, "ci", "frightened")) continue;
            let effect = (await ActiveEffect.implementation.fromStatusEffect("frightened")).toObject();
            delete effect._id;
            effect.name = "Fell Glare";
            effect.origin = workflow.item.uuid;
            effect.duration = tracked ? {seconds: 18} : {seconds: 12};
            if (tracked) effect.flags = {...effect.flags, world: {faithfulSteedFellGlare: {
                paladinUuid: paladin.uuid, combatId: combat.id, round: combat.round, turn: combat.turn
            }}};
            await genericUtils.createEmbeddedDocuments(target.actor, "ActiveEffect", [effect]);
            void animate(workflow.item, target, "effectAnimation");
        }
    } else {
        let targets = form === "celestial" ? workflow.targets : workflow.hitTargets;
        for (let target of targets ?? []) void animate(workflow.item, target, "effectAnimation");
    }
}

async function expireGlare(trigger, ended = false) {
    let token = trigger.token?.document ?? trigger.token;
    let actor = token?.actor;
    let combat = trigger.combat ?? game.combat;
    if (!actor || (!ended && !combat) || !token.parent) return;
    let affected = new Set(token.parent.tokens.map(doc => doc.actor).filter(Boolean));
    for (let recipient of affected) {
        let effects = recipient.effects.filter(effect => {
            let glare = effect.flags.world?.faithfulSteedFellGlare;
            return glare?.paladinUuid === actor.uuid && (ended || (glare.combatId === combat.id &&
                (trigger.previousRound > glare.round || (trigger.previousRound === glare.round && trigger.previousTurn > glare.turn))));
        });
        if (effects.length) await genericUtils.deleteEmbeddedDocuments(recipient, "ActiveEffect", effects.map(effect => effect.id));
    }
}

async function maintainAtTurn(trigger) {
    let token = trigger.token?.document ?? trigger.token;
    let subject = token?.actor;
    if (!subject) return;
    await dismissWhenNeeded(subject);
    let {paladin, steed} = await pair(subject);
    if (!active(steed)) return;
    await syncProfile(paladin, steed);
    await setInitiative(paladin, steed, token.parent);
}

async function resetPowers(subject) {
    let {steed} = await pair(subject);
    if (!steed) return;
    let updates = Object.values(forms).map(form => cprItem(steed, form.power))
        .filter(item => item?.system.uses.spent > 0).map(item => ({_id: item.id, "system.uses.spent": 0}));
    if (updates.length) await genericUtils.updateEmbeddedDocuments(steed, "Item", updates);
}

switch (phase) {
    case "Faithful Steed Controls": {
        let template;
        if (workflow.activity.id === "steedBindBond001" || workflow.activity.id === "steedRefresh0001") {
            template = (await game.packs.get("motos-meticulous-machinations.machinations-spells")?.getDocument("kA1QuR412qiDzNB4"))?.toObject();
        }
        return await featureUse(workflow, template);
    }
    case "Watch Actor State": return await dismissWhenNeeded(actor);
    case "Catch Spell Healing": return await recordHealing(workflow, trigger.token, ditem);
    case "Share Spell Healing": return await resolveHealing(workflow, trigger.token);
    case "Synchronize the Steed": return await maintainAtTurn(trigger);
    case "End Fell Glare": return await expireGlare(trigger);
    case "Clear Fell Glare at Combat End": return await expireGlare(trigger, true);
    case "Recover Form Power": return await resetPowers(actor);
    case "Place the Permanent Steed": return await planSummon(workflow);
    case "Summon the Permanent Steed": return await finishSummon(workflow);
    case "Check Otherworldly Slam": return await powerGuard(workflow);
    case "Animate Otherworldly Slam": return await finishPower(workflow);
    case "Check Fey Step": return await powerGuard(workflow, "fey");
    case "Resolve Fey Step": return await finishPower(workflow, "fey");
    case "Check Healing Touch": return await powerGuard(workflow, "celestial");
    case "Resolve Healing Touch": return await finishPower(workflow, "celestial");
    case "Check Fell Glare": return await powerGuard(workflow, "fiend");
    case "Resolve Fell Glare": return await finishPower(workflow, "fiend");
}
}

function checkSteedAfterUpdate(actor) {
    if (!game.users.activeGM?.isSelf || !actor.flags.world?.faithfulSteedBond?.role) return;
    void runFaithfulSteed("Watch Actor State", {actor}).catch(error => console.error("Faithful Steed state check", error));
}

Hooks.on("updateActor", (actor, change) => {
    if (foundry.utils.getProperty(change, "system.attributes.hp.value") !== undefined ||
        foundry.utils.getProperty(change, "system.attributes.death.failure") !== undefined) checkSteedAfterUpdate(actor);
});
Hooks.on("createActiveEffect", effect => {
    if (effect.parent?.documentName === "Actor" && effect.statuses.has("dead")) checkSteedAfterUpdate(effect.parent);
});
Hooks.on("preCreateActiveEffect", effect => {
    let binding = effect.parent?.flags.world?.faithfulSteedBond;
    if (binding?.role === "steed" && binding.paladinUuid && effect.statuses.has("bleeding-out")) return false;
});
