import {buttons, promptSession} from "./prompts.mjs";
import {getLuckFeat, luckPoints, spendLuckPoint} from "./luck-points.mjs";

const moduleId = "motos-meticulous-machinations";
const luckyId = "luckyOrigin";
const protectedId = "protectedOrigin";
const shieldAnimation = "jb2a.shield.02.complete.01.white";
const pendingChoices = new WeakSet();
const defaultThreshold = 12;

function findFeats(actor) {
    const lucky = getLuckFeat(actor, luckyId);
    const protector = getLuckFeat(actor, protectedId);
    return {lucky, protector};
}

async function offer(item, heading, detail, action, valid = () => true, userId) {
    const eligible = () => valid() && luckPoints(item) > 0;
    if (!eligible()) return false;
    const guardian = item.flags["chris-premades"].info.identifier === protectedId;
    const accent = guardian ? "#a6dbeb" : "#edce80";
    const background = guardian ? "#152937" : "#172e26";
    const remaining = luckPoints(item);
    const content = `<section style="padding:16px;border:1px solid ${accent};border-radius:12px;background:${background};color:#f7f3e8;line-height:1.5;overflow-wrap:anywhere">
        <div style="color:${accent};font-size:11px;letter-spacing:.1em;text-transform:uppercase">${foundry.utils.escapeHTML(item.actor.name)} &bull; ${remaining} Luck Point${remaining === 1 ? "" : "s"} left</div>
        <h2 style="margin:8px 0;color:${accent};border:0">${heading}</h2><p style="margin:0">${detail}</p>
    </section>`;
    const session = promptSession(item.actor, eligible);
    if (userId) session.userId = userId;
    const selection = await buttons(session, item.name, content, [
        [action, "spend"], ["Keep my Luck Point", "decline"]
    ]);
    return selection === "spend" && eligible();
}

const keptResult = roll => roll?.d20?.results.find(result => result.active && !result.discarded && !result.rerolled);
const dieValue = result => result.count ?? result.result;
const firstResult = roll => roll.d20.results.find(result => !result.rerolled);
const itemId = item => item.flags["chris-premades"].info.identifier;

function targetNumber(roll, workflow) {
    if (!workflow?.targets?.size) return roll.options.target;
    let target = 0;
    for (const token of workflow.targets) {
        const descriptor = workflow.targetDescriptors?.find(entry => entry.uuid === token.actor?.uuid);
        if (descriptor?.ac === null) continue;
        const ac = descriptor?.ac ?? token.actor?.system.attributes.ac?.value;
        if (!Number.isFinite(ac)) return roll.options.target;
        target = Math.max(target, ac);
    }
    // Midi treats targets with a null AC descriptor as behind total cover.
    return target || Infinity;
}

function getNoDCThreshold(item) {
    const configured = item.flags["chris-premades"].config?.noDCThreshold;
    const threshold = configured === "" ? defaultThreshold : Number(configured);
    return Number.isFinite(threshold) ? threshold : defaultThreshold;
}

function canUseOwnLuck(item, roll, workflow) {
    const kept = keptResult(roll);
    if (!item || !kept || workflow?.aborted || kept.result === 20 || luckPoints(item) < 1) return false;
    const id = itemId(item);
    const tracker = workflow?.tracker;
    if (roll.options.mmmLuckOptionsUsed?.includes(id) || tracker?.modifiers?.willFail ||
        tracker?.modifiers?.willSucceed || roll.d20.options.maximum === 1) return false;
    if (workflow && (roll.isCritical || workflow.isCritical)) return false;
    if (id === protectedId) {
        if (kept.result < 1 || kept.result > 9) return false;
    } else {
        if (roll.hasAdvantage || roll.options.mmmLuckCancelledDisadvantage ||
            (!roll.hasDisadvantage && roll.options.disadvantage)) return false;
        if (roll.hasDisadvantage) {
            const first = firstResult(roll);
            if (!first || dieValue(first) <= dieValue(kept)) return false;
        }
    }
    const dc = targetNumber(roll, workflow);
    if (dc === Infinity) return false;
    if (Number.isFinite(dc)) return kept.result === 1 || roll.total < dc;
    if (id === protectedId) return true;
    const threshold = getNoDCThreshold(item);
    return threshold !== 0 && (kept.result === 1 || roll.total <= threshold);
}

function canUseNativeOption(id, workflow, messageData) {
    try {
        const actor = workflow?.actor ?? ChatMessage.implementation.getSpeakerActor(messageData?.speaker);
        const raw = messageData?.rolls?.[0];
        const roll = workflow?.attackRoll ?? (typeof raw === "string" ? Roll.fromJSON(raw) : undefined);
        if (!game.user.isGM && (messageData?.blind || roll?.options.rollMode === "blindroll")) return false;
        return canUseOwnLuck(getLuckFeat(actor, id), roll, workflow);
    } catch (error) {
        console.warn("Machinations could not read the roll for a Luck Point option", error);
        return false;
    }
}

function addedDie(roll, number, allowHalflingLuck = true) {
    const modifiers = roll.d20.modifiers.filter(modifier => /^min|max/.test(modifier) ||
        (allowHalflingLuck && modifier === "r1=1"));
    return new CONFIG.Dice.D20Die({number, modifiers});
}

async function keepResult(roll, kept, mode = roll.options.advantageMode) {
    const die = roll.d20;
    die.applyAdvantage(mode);
    roll.options.advantageMode = mode;
    for (const result of die.results) {
        if (result.rerolled) continue;
        result.active = result === kept;
        result.discarded = !result.active;
    }
    roll.resetFormula();
    roll._total = await roll._evaluateASTAsync(CONFIG.Dice.parser.toAST(roll.terms));
}

async function imposeDisadvantage(workflow, roll) {
    if (!workflow || workflow.targets?.size !== 1 || workflow.aborted) return;
    const defender = workflow.targets.first();
    const feat = getLuckFeat(defender?.actor, luckyId);
    if (!feat || defender.actor === workflow.actor || !roll.validD20Roll) return;
    const {DISADVANTAGE, NORMAL} = CONFIG.Dice.D20Roll.ADV_MODE;
    if (roll.hasDisadvantage || (roll.options.advantageMode === NORMAL && workflow.tracker.hasDisadvantage)) return;
    const valid = () => !workflow.aborted && workflow.targets?.size === 1 && workflow.targets.has(defender);
    if (!await offer(feat, "Turn the Odds",
        "A creature is about to attack you. Spend 1 Luck Point to impose Disadvantage on this attack roll?",
        "Impose Disadvantage", valid) || !await spendLuckPoint(feat)) return;
    if (roll.hasAdvantage) roll.options.mmmLuckCancelledDisadvantage = true;
    roll.options.disadvantage = true;
    roll.options.advantageMode = roll.hasAdvantage ? NORMAL : DISADVANTAGE;
    roll.configureModifiers();
    workflow.tracker.disadvantage.add("luckyOrigin", feat.name);
}

async function applyOwnLuck(item, roll, valid = () => true) {
    const kept = keptResult(roll);
    if (!kept || !valid()) return false;
    const {ADVANTAGE, NORMAL} = CONFIG.Dice.D20Roll.ADV_MODE;
    const id = itemId(item);
    if (id === luckyId && roll.hasDisadvantage) {
        if (!await spendLuckPoint(item)) return false;
        await keepResult(roll, firstResult(roll), NORMAL);
    } else if (id === luckyId) {
        const extra = await addedDie(roll, roll.d20.options.elvenAccuracy ? 2 : 1).evaluate();
        if (!valid() || !await spendLuckPoint(item)) return false;
        roll.d20.results.push(...extra.results);
        const best = extra.results.filter(candidate => candidate.active && !candidate.rerolled)
            .reduce((current, candidate) => dieValue(current) >= dieValue(candidate) ? current : candidate, kept);
        await keepResult(roll, best, ADVANTAGE);
    } else {
        const reroll = await addedDie(roll, 1, false).evaluate();
        if (!valid() || !await spendLuckPoint(item)) return false;
        roll.d20.results.push(...reroll.results);
        kept.rerolled = true;
        kept.active = false;
        await keepResult(roll, reroll.results.find(candidate => candidate.active));
    }
    roll.options.mmmLuckOptionsUsed = [...(roll.options.mmmLuckOptionsUsed ?? []), id];
    return true;
}

async function useNativeOption(id, {actor, args, workflow}) {
    const roll = args?.[0]?.roll;
    const attack = workflow?.attackRoll ? workflow : undefined;
    const item = getLuckFeat(actor, id);
    const valid = () => canUseOwnLuck(item, roll, attack);
    if (!valid() || pendingChoices.has(roll)) return roll;
    pendingChoices.add(roll);
    try {
        const updated = Roll.fromData(roll.toJSON());
        if (roll.flags) updated.flags = foundry.utils.deepClone(roll.flags);
        if (!await applyOwnLuck(item, updated, valid)) return roll;
        // Preserve the choice on the original too, in case a second click is already queued.
        roll.options.mmmLuckOptionsUsed = updated.options.mmmLuckOptionsUsed;
        return updated;
    } catch (error) {
        console.warn("Machinations could not apply the Luck Point option", error);
        return roll;
    } finally {
        pendingChoices.delete(roll);
    }
}

async function finishD20(roll, {lucky, protector}, workflow, userId) {
    if (lucky) {
        const valid = () => canUseOwnLuck(lucky, roll, workflow);
        if (valid() && await offer(lucky, "Tilt the Odds",
            `Your total was <strong>${roll.total}</strong>. ${roll.hasDisadvantage
                ? "Spend 1 Luck Point to cancel Disadvantage and use the first die rolled?"
                : "Spend 1 Luck Point to gain Advantage on this test?"}`, "Use Lucky", valid, userId)) {
            await applyOwnLuck(lucky, roll, valid);
        }
    }
    if (protector) {
        const valid = () => canUseOwnLuck(protector, roll, workflow);
        if (valid() && await offer(protector, "A Guardian's Second Chance",
            `Your kept d20 showed <strong>${keptResult(roll).result}</strong>. Spend 1 Luck Point to reroll that die? You must use the new result.`,
            "Reroll the d20", valid, userId)) {
            await applyOwnLuck(protector, roll, valid);
        }
    }
}

function rollRecipient(mode) {
    if (mode === "blindroll") return game.users.activeGM?.id ?? game.user.id;
    if (mode === "selfroll" || (mode === "gmroll" && game.user.isGM)) return game.user.id;
}

async function evaluateD20(wrapped, rolls, config = {}, message = {}) {
    const bypass = config.evaluate === false || config.simulate || config.midiOptions?.simulate || config.workflow?.aborted ||
        !config.hookNames?.includes("d20Test") || !rolls?.some(roll => roll.validD20Roll);
    if (bypass) return wrapped(rolls, config, message);
    const workflow = config.workflow;
    const attack = config.hookNames.includes("attack");
    if (attack) await imposeDisadvantage(workflow, rolls[0]);
    if (config.disadvantage || workflow?.tracker?.hasDisadvantage) {
        for (const roll of rolls) if (!roll.hasDisadvantage) roll.options.mmmLuckCancelledDisadvantage = true;
    }
    const result = await wrapped(rolls, config, message);
    const feats = findFeats(config.subject?.actor ?? config.subject);
    if (feats.lucky || feats.protector) {
        const mode = message.rollMode ?? game.settings.get("core", "rollMode");
        const standardPicker = !config.hookNames.includes("deathSave") && (!attack || workflow);
        for (const roll of rolls) {
            const rollMode = roll.options.rollMode ?? mode;
            const native = standardPicker && (game.user.isGM || rollMode !== "blindroll");
            const fallback = {
                lucky: native && feats.lucky?.flags[moduleId]?.nativeLuckOption ? undefined : feats.lucky,
                protector: native && feats.protector?.flags[moduleId]?.nativeLuckOption ? undefined : feats.protector
            };
            await finishD20(roll, fallback, attack ? workflow : undefined, rollRecipient(rollMode));
        }
    }
    return result;
}

function configureInitiative(wrapped, formula) {
    const roll = wrapped(formula);
    if (!roll?.validD20Roll || !this.actor) return roll;
    const feats = findFeats(this.actor);
    if (feats.lucky || feats.protector) {
        const evaluate = roll.evaluate.bind(roll);
        roll.evaluate = async options => {
            const wasEvaluated = roll._evaluated;
            const result = await evaluate(options);
            if (!wasEvaluated && !options?.minimize && !options?.maximize) {
                const mode = this.hidden ? "gmroll" : game.settings.get("core", "rollMode");
                await finishD20(roll, feats, undefined, rollRecipient(mode));
            }
            return result;
        };
    }
    return roll;
}

function lethalDamage(actor, workflow, damage) {
    if (!damage?.damageDetail || !damage.rawDamageDetail || workflow.aborted || damage.isHit === false || damage.wasHit === false ||
        damage.oldHP < 1 || damage.newHP !== 0 || damage.hpDamage <= 0 || actor.statuses.has("dead")) return false;
    const hp = actor.system.attributes.hp;
    const damageToHP = damage.healingAdjustedTotalDamage - damage.oldTempHP;
    return hp.value === damage.oldHP && damageToHP >= damage.oldHP && damageToHP - damage.oldHP < (hp.effectiveMax ?? hp.max);
}

async function animateStabilize(item, token) {
    const {itemUtils, animationUtils} = chrisPremades.utils;
    if (!token || !itemUtils.getConfig(item, "playAnimation") || !animationUtils.jb2aCheck() || !globalThis.Sequence) return;
    const file = itemUtils.getConfig(item, "stabilizeAnimation")?.trim() || shieldAnimation;
    try {
        await new Sequence().effect().file(file).atLocation(token).scaleToObject(1.35).play();
    } catch (error) {
        console.warn("Machinations could not play the Protected animation", error);
    }
}

async function stabilize(item, token, workflow, damage) {
    const actor = item.actor;
    const valid = () => lethalDamage(actor, workflow, damage);
    if (!valid() || !await offer(item, "Held at the Threshold",
        "This damage would put you at 0 HP. Spend 1 Luck Point to stay at 1 HP?",
        "Stay at 1 HP", valid) || !await spendLuckPoint(item)) return;

    // Preserve temporary HP loss, other damage types, and any simultaneous healing.
    const reduction = damage.healingAdjustedTotalDamage - (damage.oldHP - 1 + damage.oldTempHP);
    const adjustment = {type: "none", value: -reduction, damage: -reduction, active: {multiplier: 1}};
    damage.damageDetail.push(adjustment);
    damage.rawDamageDetail.push({...adjustment});
    damage.totalDamage -= reduction;
    damage.healingAdjustedTotalDamage -= reduction;
    damage.hpDamage = damage.oldHP - 1;
    damage.newHP = 1;
    void animateStabilize(item, token);
}

Hooks.once("ready", () => {
    const module = game.modules.get(moduleId);
    module.api = {...module.api, luckFeats: {stabilize}};
    CONFIG.MachinationsLuckFeats = {
        eligible: canUseNativeOption,
        luckyReroll: data => useNativeOption(luckyId, data),
        protectedReroll: data => useNativeOption(protectedId, data)
    };
    libWrapper.register(moduleId, "CONFIG.Dice.D20Roll.buildEvaluate", evaluateD20, "WRAPPER");
    libWrapper.register(moduleId, "CONFIG.Combatant.documentClass.prototype.getInitiativeRoll", configureInitiative, "WRAPPER");
});
