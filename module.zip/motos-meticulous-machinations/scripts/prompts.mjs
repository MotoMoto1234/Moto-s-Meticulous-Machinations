const moduleId = "motos-meticulous-machinations";
const pendingPlayers = new Map();
const openWindows = new Map();
const cancelledWindows = new Set();
const reconnectClosures = new Map();
let socket;

function playerTimeout() {
    const seconds = Number(MidiQOL.configSettings().reactionTimeout);
    return (Number.isFinite(seconds) && seconds > 0 ? seconds : 30) * 1000;
}

export function promptSession(actor, valid = () => true) {
    const userId = chrisPremades.utils.socketUtils.firstOwner(actor, true);
    return {userId, actorName: actor.name, valid, fallback: false};
}

function closePrompt(id) {
    if (openWindows.has(id)) {
        openWindows.get(id)();
    } else {
        // A cancellation can arrive before the matching display request.
        cancelledWindows.add(id);
        if (cancelledWindows.size > 256) cancelledWindows.delete(cancelledWindows.values().next().value);
    }
}

function gmBanner(actorName, ownerName) {
    const escape = foundry.utils.escapeHTML;
    return `<aside role="note" style="margin:0 0 12px;padding:12px;border:2px solid #e6b35a;border-radius:8px;background:#3b2813;color:#fff0cf;overflow-wrap:anywhere"><strong>GM FALLBACK</strong><br>${escape(ownerName)} did not respond. Decide for <strong>${escape(actorName)}</strong>. The remaining choices in this sequence will come to you.</aside>`;
}

function showDialog(spec, control) {
    const dialog = new chrisPremades.DialogApp([
        spec.title, spec.content, spec.inputs, spec.buttons, {width: 470}
    ]);
    return new Promise(resolve => {
        let finished = false;
        const finish = response => {
            if (finished) return;
            finished = true;
            resolve(response);
        };
        const close = () => Promise.resolve(dialog.close()).catch(console.error);
        dialog.addEventListener("close", () => finish({status: "closed"}), {once: true});
        dialog.addEventListener("render", () => {
            if (finished) close();
        });
        dialog.submit = response => {
            finish(control.expired() ? {status: "expired"} : {status: "answered", response});
            close();
        };
        control.cancel = () => {
            finish({status: "expired"});
            close();
        };
        Promise.resolve(dialog.render({force: true})).catch(error => {
            console.error("Machinations prompt could not render", error);
            finish({status: "unavailable"});
        });
    });
}

async function pickPoint(spec, control) {
    if (canvas.scene?.id !== spec.point.sceneId) return {status: "unavailable"};
    if (spec.content) {
        const notice = await showDialog({...spec, buttons: "okCancel", inputs: []}, control);
        if (notice.status !== "answered" || !notice.response?.buttons) return notice;
    }
    if (control.expired()) return {status: "expired"};
    const {sceneId, ...config} = spec.point;
    const point = await chrisPremades.Crosshairs.showCrosshairs(config, {show(preview) {
        control.cancel = () => {
            if (!preview.inFlight) return;
            preview.cancelled = true;
            preview.clearHandlers();
        };
        if (control.expired()) control.cancel();
    }});
    if (control.expired()) return {status: "expired"};
    return point.cancelled ? {status: "closed"} : {status: "answered", response: {x: point.x, y: point.y}};
}

async function displayPrompt({id, recipient, spec, timeout}) {
    if (recipient !== game.user.id || cancelledWindows.delete(id) || openWindows.has(id)) {
        return {status: "unavailable"};
    }
    const deadline = !game.user.isGM && timeout ? Date.now() + timeout : Infinity;
    let cancelled = false;
    const control = {expired: () => cancelled || Date.now() >= deadline, cancel: () => {}};
    const cancel = () => {
        cancelled = true;
        control.cancel();
    };
    openWindows.set(id, cancel);
    const timer = Number.isFinite(deadline) ? setTimeout(cancel, timeout) : undefined;
    try {
        return await (spec.point ? pickPoint(spec, control) : showDialog(spec, control));
    } finally {
        clearTimeout(timer);
        openWindows.delete(id);
    }
}

function sendPrompt(userId, spec, timeout) {
    const id = foundry.utils.randomID();
    const payload = {id, recipient: userId, spec, timeout};
    const local = userId === game.user.id;
    if (!local && !socket) return Promise.resolve({status: "unavailable"});
    const answer = () => local ? displayPrompt(payload) : socket.executeAsUser("displayMachinationsPrompt", userId, payload);
    const result = Promise.resolve().then(answer).catch(error => {
        console.warn("Machinations prompt recipient unavailable", error);
        return {status: "unavailable"};
    });
    if (!timeout) return result;
    const deadline = Date.now() + timeout;
    let timer;
    const watchdog = new Promise(resolve => {
        const abandon = () => resolve({status: "expired"});
        pendingPlayers.set(id, {userId, abandon});
        timer = setTimeout(abandon, timeout);
    });
    return Promise.race([result, watchdog]).then(reply => {
        if (Date.now() >= deadline || !["answered", "closed"].includes(reply?.status)) {
            if (local) closePrompt(id);
            else requestClose(userId, id);
            return {status: "expired"};
        }
        return reply;
    }).finally(() => {
        clearTimeout(timer);
        pendingPlayers.delete(id);
    });
}

function requestClose(userId, id) {
    const enqueue = () => {
        reconnectClosures.set(id, userId);
        if (reconnectClosures.size > 256) reconnectClosures.delete(reconnectClosures.keys().next().value);
    };
    if (!game.users.get(userId)?.active) {
        enqueue();
        return;
    }
    Promise.resolve().then(() => socket.executeAsUser("closeMachinationsPrompt", userId, id)).catch(enqueue);
}

export async function ask(session, spec, {notice = false} = {}) {
    if (!session.valid()) return null;
    let recipient = game.users.get(session.userId);
    let reply;
    if (recipient?.active && !session.fallback) {
        reply = await sendPrompt(recipient.id, spec, recipient.isGM ? undefined : playerTimeout());
        if (reply?.status === "answered" || reply?.status === "closed" || recipient.isGM || notice) {
            return session.valid() ? reply?.response ?? null : null;
        }
    }
    if (notice || !session.valid()) return null;
    const gm = game.users.activeGM;
    if (!gm?.active) {
        ui.notifications.warn("Machinations needs an active GM to answer the timed-out prompt.");
        return null;
    }
    session.ownerName ??= recipient?.name ?? session.actorName;
    session.userId = gm.id;
    session.fallback = true;
    const result = await sendPrompt(gm.id, {...spec,
        title: "GM Fallback | " + spec.title,
        content: gmBanner(session.actorName, session.ownerName) + (spec.content ?? "")
    });
    return session.valid() ? result?.response ?? null : null;
}

function buttonFields(choices) {
    return [["button", choices.map(([label, name]) => ({label, name})), {displayAsRows: true}]];
}

export async function buttons(session, title, content, choices, options) {
    const result = await ask(session, {title, content, inputs: buttonFields(choices)}, options);
    return result?.buttons;
}

Hooks.once("ready", () => {
    const mod = game.modules.get(moduleId);
    mod.api = {...mod.api, prompts: {promptSession, ask, buttons}};
});
Hooks.once("socketlib.ready", () => {
    socket = globalThis.socketlib?.registerModule(moduleId);
    socket?.register("displayMachinationsPrompt", displayPrompt);
    socket?.register("closeMachinationsPrompt", closePrompt);
});
Hooks.on("userConnected", (user, active) => {
    if (active) {
        for (const [id, recipient] of reconnectClosures) {
            if (recipient !== user.id) continue;
            reconnectClosures.delete(id);
            requestClose(recipient, id);
        }
        return;
    }
    for (const request of pendingPlayers.values()) {
        if (request.userId === user.id) request.abandon();
    }
});
