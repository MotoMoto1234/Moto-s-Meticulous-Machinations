const customReactionSpells = new Set([
    "callToAction", "nobleSacrifice", "orrosMarkOfFateCustom", "shieldingWord", "weavebendCustom"
]);

Hooks.on("midi-qol.ReactionFilter", (activities, _options, _trigger, references) => {
    // Midi skips use conditions for spells when this setting is enabled.
    if (!MidiQOL.configSettings().ignoreSpellReactionRestriction) return;
    const blocked = new Set();
    for (let index = activities.length - 1; index >= 0; index--) {
        const activity = activities[index];
        const identifier = activity?.item?.flags?.["chris-premades"]?.info?.identifier;
        if (activity?.useConditionText?.trim() !== "false" || !customReactionSpells.has(identifier)) continue;
        if (activity.uuid) blocked.add(activity.uuid);
        activities.splice(index, 1);
    }
    if (!blocked.size) return;
    for (let index = (references?.length ?? 0) - 1; index >= 0; index--) {
        const reference = references[index];
        if (blocked.has(typeof reference === "string" ? reference : reference?.uuid)) references.splice(index, 1);
    }
});
